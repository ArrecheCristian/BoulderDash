package archivos;

import java.io.*;

import juego.Juego;

public class Ranking {
	
	private static Ranking ranking;
	private Jugador[] jugadores = new Jugador[20];
	private ObjectOutputStream salida; 
	private ObjectInputStream entrada;
	private File archivoAuxiliar;
	private Jugador jugador;
	private boolean agregar;
	
	
	private Ranking(){
		
		archivoAuxiliar = new File("ranking");
		if( !archivoAuxiliar.exists() ){
			try {
				archivoAuxiliar.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		for(int i=0; i<20; i++){
			jugadores[i] = new Jugador();
			jugadores[i].setPuesto(i+1);
		}
	}
	
	public static Ranking getInstance(){
		if (ranking == null)
			ranking = new Ranking();
		return ranking;
	}
	
	public Jugador[] getJugadores(){
		try {
			leerJugadores();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jugadores;
	}
	
	
	
	public boolean isAgregar() {
		return agregar;
	}

	
	public void leerJugadores() throws IOException {
		
		try{
			entrada = new ObjectInputStream(new FileInputStream(archivoAuxiliar));
			jugadores = (Jugador[]) entrada.readObject();     
	    }
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		finally{
			try{
				if( entrada != null)
					entrada.close();
			}
			catch (IOException e){
				e.printStackTrace();
			}
		}
	}

	
	private void guardarJugadores(){
		try{
			salida = new ObjectOutputStream( new FileOutputStream(archivoAuxiliar)); 
			salida.writeObject(jugadores);
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		finally{
			try{
				if( salida != null)
					salida.close();
			}
			catch (IOException e){
				e.printStackTrace();
			}			
	    }
	}
	
	
	public int evaluarJugador(int puntaje, int tiempo){
		
		try {										
			leerJugadores();			
			for(int i=0; i<20; i++){
				if( puntaje > jugadores[i].getPuntos() ){ 
					agregar = true;
					return i;
				}
				else{			
					if( (puntaje == jugadores[i].getPuntos()) && (tiempo < jugadores[i].getTiempo()) ){
						agregar = true;
						return i;
					}
				}
			}
		}
		catch(EOFException e ){ 								
		    agregar = true;
			return 0; 				//Agrega en la pos 0, el archivo esta vacio.
		}
		catch(IOException e){
			e.getMessage();
		}
		agregar = false;
		return -1;
	}
	

	
	public void nuevoJugador(int pos, String nombre, int puntaje, int tiempo){
		
		for( int j=19 ; j>pos ; j--){
			jugadores[j].setNombre(jugadores[j-1].getNombre());
			jugadores[j].setPuntos(jugadores[j-1].getPuntos());
			jugadores[j].setPuesto(jugadores[j-1].getPuesto()+1);
			jugadores[j].setTiempo(jugadores[j-1].getTiempo());
					
		}
		jugadores[pos].setPuesto(pos+1);
		jugadores[pos].setPuntos(puntaje);
		jugadores[pos].setTiempo(tiempo);
		jugadores[pos].setNombre(nombre);
		
		guardarJugadores();
	}
	
	
}	
		


	
	

