package archivos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Configuracion {
	
	private static Configuracion configuracion;
	private int  topVisible = 5;
	private ObjectOutputStream salida; 
	private ObjectInputStream entrada;
	private File archivoAux;
	
	private Configuracion(){
		archivoAux = new File("configuracion");
		if( !archivoAux.exists() ){
			try {
				archivoAux.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static Configuracion getInstance(){
		if (configuracion == null)
			configuracion = new Configuracion();
		return configuracion;
	} 
	
	public void guardarConfiguracion(){
		try{
			salida = new ObjectOutputStream( new FileOutputStream(archivoAux)); 
			salida.writeInt(topVisible);
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		finally{
			try{
				if( salida != null)
					salida.close();
			}
			catch (IOException e){
				e.printStackTrace();
			}			
	    }
	}
	
	
	public int getTopVisible() {
		return topVisible;
	}

	public void setTopVisible(int topVisible) {
		this.topVisible = topVisible;
	}

	public int leerConfiguracion(){
		try{
			entrada = new ObjectInputStream(new FileInputStream(archivoAux));
			topVisible =  entrada.readInt();
	    }
    	catch(IOException e ){
    	}
		finally{
			try{
				if( entrada != null)
					entrada.close();
			}
			catch (IOException e){
				e.printStackTrace();
			}
		}
		return topVisible;
	}
}
