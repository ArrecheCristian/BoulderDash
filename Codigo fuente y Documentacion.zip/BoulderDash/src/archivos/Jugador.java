package archivos;

import java.io.Serializable;

public class Jugador implements Serializable{
	
	private int puesto;
	private String nombre;
	private int puntos;
	private int tiempo;
	
	public Jugador(){
		
	}
	
	public Jugador(int puesto, String nombre, int puntos, int tiempo){
		this.puesto = puesto;
		this.nombre = nombre;
		this.puntos = puntos;
		this.tiempo = tiempo;
	}
	
	
	public int getPuesto() {
		return puesto;
	}
	public void setPuesto(int puesto) {
		this.puesto = puesto;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
	public int getTiempo() {
		return tiempo;
	}
	public void setTiempo(int tiempo) {
		this.tiempo = tiempo;
	}

		

	
	
}
