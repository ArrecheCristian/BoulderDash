package excepciones;

import javax.swing.JOptionPane;
import grafica.ErrorImagen;

public class ExcepcionImagenNoEncontrada extends Exception{
	
	public void errorCargarImagen(){
		new ErrorImagen();
		System.exit(1);
	}
	
}
