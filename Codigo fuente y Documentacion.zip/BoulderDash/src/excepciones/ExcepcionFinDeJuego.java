package excepciones;

import grafica.JuegoTerminado;

public class ExcepcionFinDeJuego extends Exception{
	
	public void juegoTerminado(){
			new JuegoTerminado();
	}
}
