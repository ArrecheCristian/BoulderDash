package personajes;

/**
 * Clase que representa el comportamiento/atributo del tipo de personaje Roca.
 * @author ARRECHE-BORINI
 *
 */
public class Roca extends Dinamico {
	
	private EstadoRoca estado;					//utilizamos el patron de dise�o state para definir los estados posibles, ya que tienen distintos comportamientos
	
	
	/**
	 * Constructor vacio
	 */
	public Roca(){
		
	}
	
	/**
	 * Constructor con seteo de posicion y seteo de estado (cayendo o estatico) 
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 * @param estaCayendo. True si est� cayendo, false si est� estacionaria.
	 */
	public Roca(int posX, int posY, boolean estaCayendo){
		super(posX, posY);
		if ( estaCayendo )
			estado = new RocaCayendo();
		else
			estado = new RocaEstacionaria();	
	}
	
	
	public EstadoRoca getEstado() {
		return estado;
	}

	public void setEstado(EstadoRoca estado) {
		this.estado = estado;
	}
	
	
	/**
	 * Establece el comportamiento del objeto Roca al entrar en contacto con Rockford, el comportamiento que se ejecutar�,
	 *  depende del estado actual en el que se encuentre la roca. 
	 * @param nuevaPos
	 *  Nueva posicion donde quiere moverse Rockford 
	 */
	public void contactoConRockford(Posicion nuevaPos){
		estado.contactoConRockford(nuevaPos);
	}
	
	
	/**
	 *Actualizacion del estado actual del objeto, el comportamiento que se ejecutar� depende del estado actual en el que se encuentre la roca.
	 */
	public void actualizarEstado(){
		estado.actualizarEstado(this);
	}
	
	
	public void validarMovimiento(){
		estado.validarMovimiento();
	}
	
	
	/**
	 * Retorna si es Roca o no.
	 * @return true: si es Roca. False: si no es Roca.
	 */
	public boolean esRoca(){
		return true;
	}


}
