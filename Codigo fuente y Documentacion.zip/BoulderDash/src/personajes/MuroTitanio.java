package personajes;


/**
 * Clase que establece el comportamiento de los personaje de tipo Muro Magico
 * @author ARRECHE-BORINI
 *
 */

public class MuroTitanio extends Estatico {
	
	
	/**
	 * Constructor vacio
	 */
	public MuroTitanio(){
		
	}
	
	/**
	 * Constructor con seteo de posicion 
	 * @param posX: coordenada en X de la pos
	 * @param posY: coordenada en Y de la pos. 
	 */
	public MuroTitanio(int posX, int posY){
		super(posX, posY);
	}

	/**
	 * Establece el comportamiento al entrar en contacto con Rockford, al ser un Muro Titanio, este no permite el avance de Rockford.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford.
	 */
	public void contactoConRockford(Posicion nuevaPos){
	}
	
	/**
	 * retorna si es Muro de titanio o no.
	 * @return true si es un Muro de Titanio. False si no es un Muro de Titanio.
	 */
	public boolean esMuroTitanio(){
		return true;
	}

}