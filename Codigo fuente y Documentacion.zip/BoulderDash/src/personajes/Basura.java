package personajes;

import juego.Juego;


/**
 * Clase que define el personaje tipo Basura , tanto su comportamiento como atributos.
 * @author ARRECHE-BORINI
 */
public class Basura extends Estatico {
   
	private Personaje [][] map = Juego.getInstance().getMap();
	private Rockford rockford = Rockford.getInstance();
	
	/**
	 * Constructor vacio
	 */
	public Basura(){	
	}
	
	/**
	 * Constructor con seteo de posicion 
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 */
	public Basura(int posX, int posY){
		super(posX, posY);
	}
	
	
	/**
	 * Ejecuta el comportamiento correspondiente al entrar en contacto con rockford, al ser Basura Rockford avanza libremente.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford 
	 */
	public void contactoConRockford(Posicion nuevaPos){		//si rockford entra en contacto con Basura, puede moverse normalmente
		int xVieja = rockford.getPos().getPosX();
		int yVieja = rockford.getPos().getPosY();
		int xNueva = nuevaPos.getPosX();
		int yNueva = nuevaPos.getPosY();
				
		rockford.setPos(nuevaPos);					//se actualizan las posiciones, y se mueve Rockford
		map [xNueva][yNueva] = rockford;
		map [xVieja][yVieja] = new Vacio(xVieja, yVieja);
	}
   
	
	/**
	 * retorna si es una Basura o no.
	 * @return true si es una Basura. False si no es una Basura.
	 */
	public boolean esBasura(){
		return true;
	}
	

}
