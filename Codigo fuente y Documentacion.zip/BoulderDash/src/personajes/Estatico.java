package personajes;

/**
 * Clase que define el comportamiento en com�n que tendr�n los personajes que extienden de ella. 
 * @author ARRECHE - BORINI
 */
public abstract class Estatico extends Personaje {
	
	public Estatico(){	
	}
	
	/**
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 */
	public Estatico(int posX, int posY){
		super(posX, posY);
	}
	
}
