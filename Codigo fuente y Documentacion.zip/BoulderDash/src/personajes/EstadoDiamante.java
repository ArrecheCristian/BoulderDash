package personajes;

/**
 * Interface que define el comportamiento que tendr� Diamante en sus distintos estados posibles (DiamanteEstacionario y DiamanteCayendo).
 *@author ARRECHE - BORINI
 */
public interface EstadoDiamante {
										//Interface que define el comportamiento de los distintos estados de Diamante
	
	/**
	 * Reaccion ante entrar en contacto con Rockford.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford 
	 */
	void contactoConRockford(Posicion nuevaPos);
	
	
	/**
	 * Actualizara el estado de el diamante en cuestion
	 * @param diamante
	 */
	void actualizarEstado(Diamante diamante);
	
	/**
	 * Valida un �nico movimiento por turno para cada Diamante.
	 */
	void validarMovimiento();
	
}
