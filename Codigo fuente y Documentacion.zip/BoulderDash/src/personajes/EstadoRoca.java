package personajes;

/**
* Interface que define el comportamiento que tendr� Roca en sus distintos estados posibles (RocaEstacionaria y RocaCayendo).
*@author ARRECHE - BORINI
*/
public interface EstadoRoca{
										//Interface que define el comportamiento de los distintos estados de Roca. 
	
	/**
	 * Define el comportamiento al entrar en contacto con Rockford.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford 
	 */
	void contactoConRockford(Posicion nuevaPos);
	
	
	/**
	 * Actualizar� el estado de el diamante en cuestion
	 * @param roca
	 */
	void actualizarEstado(Roca roca);
	
	/**
	 * Valida un �nico movimiento por turno de la Roca.
	 */
	public void validarMovimiento();
	
}
