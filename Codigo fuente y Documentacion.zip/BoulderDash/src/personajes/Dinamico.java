package personajes;

/**
 * Clase que define el comportamiento en comun que tendran los Personajes Dinamicos. Esta hereda de Personaje, y a su vez tiene herederos que 
 * son los personajes con dichos comportamientos en com�n.
 * @author ARRECHE - BORINI
 */

public abstract class Dinamico extends Personaje{
	
	private boolean turnoRealizado;
	
	public Dinamico(){
		
	}
	
	
	/**
	 * Constructor con seteo de posiciones de personaje Dinamico. Este llama al constructor de su clase padre.
	 * @param posX
	 * @param posY
	 */
	public Dinamico(int posX, int posY){
		super(posX, posY);
	}

	
	public boolean isTurnoRealizado() {
		return turnoRealizado;
	}


	public void setTurnoRealizado(boolean turnoRealizado) {
		this.turnoRealizado = turnoRealizado;
	}


	public boolean esDinamico(){
		return true;
	}
	
	public void validarMovimiento(){
		this.turnoRealizado = false;
	}
	
}
