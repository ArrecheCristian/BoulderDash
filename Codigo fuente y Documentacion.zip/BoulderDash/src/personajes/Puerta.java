package personajes;

import juego.Juego;
/**
 * Clase restringida a la creacion de un unico objeto (Singleton) utilizada para la representacion del objeto Puerta.
 *@author ARRECHE-BORINI
 *
 */
public class Puerta extends Estatico {
	
	private static Puerta puerta;
	
	private Puerta(){	
	}
	
	
	/**
	 * Devuelve la referencia al unico objeto puerta instanciado.
	 * @return Objeto puerta.
	 */
	public static Puerta getInstance(){
		if (puerta == null)
			puerta = new Puerta();
		return puerta;
	}

	
	/**
	 * Cuando Rockford entra en contacto con la Puerta, significa que completo el nivel en el que se encuenta actualmente.
	 * Se realizan los cambios necesarios para que el modelo se encargue de setear el pr�ximo nivel.
	 * @param nuevaPos: Nueva posicion donde se mover� Rockford 
	 */
	public void contactoConRockford(Posicion nuevaPos){			//Se completo el nivel
		Personaje[][] map = Juego.getInstance().getMap();
		Rockford rockford = Rockford.getInstance();
		
		int posAuxX = rockford.getPos().getPosX();
		int posAuxY = rockford.getPos().getPosY();
		map[rockford.getPos().getPosX()][rockford.getPos().getPosY()] = new Vacio(posAuxX, posAuxY);
		rockford.setPos(nuevaPos);
		rockford.setCompletoNivel(true);
	}
	
	
	/**
	 * retorna si es Puerta o no.
	 * @return true si es Puerta. False si no es un Puerta.
	 */
	public boolean esPuerta(){
		return true;
	}

}
