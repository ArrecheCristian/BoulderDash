package personajes;

import juego.Juego;
/**
 * Clase que define el comportamiento del objeto RocaCayendo.
 * @author ARRECHE-BORINI
 */

public class RocaCayendo implements EstadoRoca {
		
	private Personaje [][] map = Juego.getInstance().getMap();
	private Rockford rockford = Rockford.getInstance();	
	private boolean turnoRealizado;
	
	@Override
	public void contactoConRockford(Posicion nuevaPos){
		//De esto se encarga el actualizarEstado() de RocaCayendo cuando evalua si tiene a Rockford debajo!!
	}


	@Override
	/**
	 * Realiza la actualizacion del estado de una Roca Cayendo, la cual 
	 * verifica qu� objeto se encuentra debajo en su trayectoria de caida y en funcion de ello el resultado de su ejecucion.
	 * @param roca: Objeto Roca en cuestion
	 */
	public void actualizarEstado(Roca roca){
		
		if ( !turnoRealizado ){
			turnoRealizado = true;
			
			Personaje personajeDebajo = map[roca.getPos().getPosX()][roca.getPos().getPosY() + 1];			//ME QUEDO CON EL PERSONAJE QUE HAYA ABAJO DE ROCA
			
			if ( personajeDebajo.esVacio() ){
				muevoRoca(roca);										//Si abajo esta vacio, la roca puede seguir cayendo sin problemas
				return ;
			}
			
			if ( personajeDebajo.esRockford() ){
				muevoRoca(roca);					
				rockford.morir();				//Si debajo esta Rockford, este explota y muere
				return;
			}
			
			if ( personajeDebajo.esMariposa() ){
				muevoRoca(roca);
				Mariposa mariposa = (Mariposa) personajeDebajo;				//Sabemos que el personaje que esta debajo es una Mariposa, entonces
				mariposa.explotar();										//casteamos para poder decirle que explote.
				return;
		       }
		       																			
			if ( personajeDebajo.esLuciernaga() ){
				muevoRoca(roca);
				Luciernaga luciernaga = (Luciernaga) personajeDebajo;		//hacemos el casteo para que la Luciernaga explote
				luciernaga.explotar();
				return;
			}
			cambiarEstado(roca);											//CUALQUIER OTRA COSA QUE HAYA DEBAJO, SOLO CAMBIA DE ESTADO
		}
	}

	
	/**
	 * Encargado del desplazamiento de la roca en su caida.
	 * @param roca: personaje Roca en cuestion.
	 */
	private void muevoRoca(Roca roca){							//La roca cae un casillero m�s en el eje Y
		
		int posX = roca.getPos().getPosX();
		int posY = roca.getPos().getPosY();
		
		Posicion posNueva = new Posicion(posX, posY + 1);
		map[posX][posY] = new Vacio(posX, posY);
		roca.setPos(posNueva);
		map[posX][posY + 1] = roca;
	}
	
	
	/**
	 * Setea el estado de la roca a RocaEstacionaria.
	 * @param roca: personaje  Roca en cuestion.
	 */
	private void cambiarEstado(Roca roca){
		RocaEstacionaria rocaEstacionaria = new RocaEstacionaria();			//CAMBIO EL ESTADO DE ROCA CAYENDO A ROCA ESTACIONARIA
		roca.setEstado(rocaEstacionaria);                               
	}
	
	
	public void validarMovimiento(){
		turnoRealizado = false;
	}
}
