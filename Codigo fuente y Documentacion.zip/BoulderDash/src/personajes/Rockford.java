package personajes;

import juego.Juego;
/**
 *  Clase restringida a la creacion de un unico objeto (Singleton) utilizada para la representacion del objeto Rockford.
 * @author Cristian
 *
 */
public class Rockford extends Dinamico{
	
	private static Rockford rockford;
	private int vidas = 4;									//Tiene 4 vidas! vida 1, 2, 3, 4
	private int diamantesNecesarios;
	private int cantDiamantes;
	private int direccion;
	private boolean completoNivel;
	private boolean murio;
	private Personaje [][] map = Juego.getInstance().getMap();
	
	/**
	 * Constructor vacio.
	 */
	private Rockford(){	
	}
	
	/**
	 * Borra la instancia creada del personaje Rockford para restaurar su estado. Luego se volver� a instanciar o no seg�n se requiera, 
	 * con su estado incial.
	 */
	public void reiniciar() {
		rockford = null;
	}


	/**
	 * Devuelve la referencia al unico objeto actualmente instanciado.
	 * @return referencia a Rockford.
	 */
	public static Rockford getInstance(){
		if ( rockford == null){
			rockford = new Rockford();
		}
		return rockford;
	}
	
	public boolean isCompletoNivel() {
		return completoNivel;
	}

	public void setCompletoNivel(boolean completoNivel) {
		this.completoNivel = completoNivel;
	}
	
	public int getDireccion() {
		return direccion;
	}

	public void setDireccion(int direccion) {
		this.direccion = direccion;
	}

	public int getDiamantesNecesarios() {
		return diamantesNecesarios;
	}

	public void setDiamantesNecesarios(int diamantesNecesarios) {
		this.diamantesNecesarios = diamantesNecesarios;
	}

	public int getVidas() {
		return vidas;
	} 
	
	public void setVidas(int vidas) {
		this.vidas = vidas;
	}
	
	public int getCantDiamantes() {
		return cantDiamantes;
	}
	
	public void setCantDiamantes(int diamantes) {
		this.cantDiamantes = diamantes;
	}
	
	public boolean isMurio() {
		return murio;
	}

	public void setMurio(boolean murio) {
		this.murio = murio;
	}


	/**
	 * Retorna si es Rockford o no.
	 * @return true: si es Rockford. False: si no es Rockford.
	 */
	public boolean esRockford(){
		return true;
	}
	
	
	/** Es el encargado del movimiento del personaje Rockford a trav�s del mapa.
	 * Ejecuta los comportamientos correspondientes al encontrarse con los diferentes personajes.
	 */
	public void actualizarEstado(){
		
			if ( !isTurnoRealizado() ){
				setTurnoRealizado(true);
				
				int x = this.getPos().getPosX();                //Me quedo con la posici�n de Rockford.
				int y = this.getPos().getPosY();
				Posicion nuevaPos = new Posicion();				//Nueva posicion donde se quiere mover Rockford.	
				
				switch (direccion) { 
				case 8 :
					nuevaPos.setPosX(x);
					nuevaPos.setPosY(y-1);
					map[x][y-1].contactoConRockford(nuevaPos);			//Se ejecutara el metodo asociado con el objeto �real�; al que hace referencia la variable en ejecuci�n(Roca, Vacio, etc.) 
					break;
				case 2 :
					nuevaPos.setPosX(x);
					nuevaPos.setPosY(y+1);
					map[x][y+1].contactoConRockford(nuevaPos);
					break;
				case 4 : 
					nuevaPos.setPosX(x-1);
					nuevaPos.setPosY(y);
					map[x-1][y].contactoConRockford(nuevaPos);
					break;
				case 6 : 
					nuevaPos.setPosX(x+1);
					nuevaPos.setPosY(y);
					map[x+1][y].contactoConRockford(nuevaPos);
					break;
				default:
					break;
				}
				direccion = 0;
			}
	}
	
	
	/**Al morir, el personaje explota. Se actualiza su cantidad de vidas actuales.
	 */
	public void morir(){
		explotar();        // Crea como max 9 objetos de expl y despues tiene que colocar los vacios.
		murio = true;
		rockford.setVidas(rockford.getVidas()-1);	
	}																							
		
	
	/**
	 * Explosion de Rockford, se compone de varios objetos Explosion ocupando
	 * un maximo 3x3 centrados en el personaje. Si alrededor existen muros de titanio, esos sectores no seran afectados.
	 */
	public void explotar(){
		Posicion PosCentral = Rockford.getInstance().getPos();
		
		int posX = PosCentral.getPosX() - 1;							//Se crean Explosion y luego Vacio en el area posible de 3*3 (si hay MuroTitanio no)
		int posY = PosCentral.getPosY() - 1;
		int y;
		int x;
		for ( y = 0; y<3; y++){
			for ( x = 0; x<3; x++){
				
				if ( !map[posX + x][posY + y].esMuroTitanio() )
					map[posX + x][posY + y] = new Explosion (posX + x, posY + y);				
			}
		}
	}		

}
