package personajes;

import juego.Juego;

/**
 * Clase que define el personaje Luciernaga con su correspondinte comportamiento.
 * @author ARRECHE - BORINI
 *
 */
public class Luciernaga  extends PersonajeExplosivo{
	
    /**
     *Constructor vacio.
     */
 	public Luciernaga(){	
 	}
 	
 	/**
 	 * Constructor con seteo de posicion de Luciernaga 
 	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
 	 */
 	public Luciernaga(int posX, int posY){
 		super(posX, posY);							
 	}
     
 	/**
	 * Retorna si es una Luciernaga o no.
	 * @return true si es una Luciernaga. False si no es una Luciernaga.
	 */
     public boolean esLuciernaga(){
 		return true;
 	}
     

     /**
      * Cambia la direccion de la Luciernaga en sentido horario cuando esta no encuentra un Vacio en la direccion que llevaba.
      */
     public void cambiarDireccion(){							//LUCIERNAGA CAMBIA SU DIRECCION EN SENTIDO HORARIO
    	 
    	 Direcciones direccionActual = this.getDirActual();
    	 switch (direccionActual){
    	 case DERECHA :
    		 this.setDirActual(Direcciones.ABAJO);     //Se sobreescribe el metodo de su clase padre. Cambio de direccion contraria a Mariposa
    		 break;
    	 case ABAJO :
    		 this.setDirActual(Direcciones.IZQUIERDA);
    		 break;
    	 case IZQUIERDA :
    		 this.setDirActual(Direcciones.ARRIBA);
    		 break;
    	 case ARRIBA : 
    		 this.setDirActual(Direcciones.DERECHA);
    		 break;
    	 }
     }
     
     
     
     /**
      * Metodo que representa la explosion de Luciernaga cuando muere. Se generan objetos Explosion en un area m�xima de 3*3 ( no incluye
      * posiciones donde se encuentre un MuroTitanio), y luego genera Vacio donde se haya producido dicha explosi�n. 
      */
     public void explotar(){			//Sobreescribe el metodo de su clase padre, al comportarse de distinta manera que Mariposa
	    
    	Personaje[][] map = Juego.getInstance().getMap(); 
    	Posicion pos = this.getPos(); 
    	
    	int posX= pos.getPosX() - 1;
    	int posY= pos.getPosY() - 1;
 		int x;
 		int y;
 															//Convierte un area de  3*3 (con ella en el centro) en Explosion y luego genera Vacios
    	for ( y = 0; y<3; y++){
    		for ( x = 0; x<3; x++){
    			if ( !map[posX + x][posY + y].esMuroTitanio() )
    				 map[posX + x][posY + y] = new Explosion(posX + x, posY + y);
   
    		}
    	}
    }

}
