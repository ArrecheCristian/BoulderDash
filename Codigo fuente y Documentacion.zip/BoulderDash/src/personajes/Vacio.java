package personajes;

import juego.Juego;
/**
 * Clase que representa los objetos personaje de tipo Vacio. 
 *@author ARRECHE-BORINI
 *
 */
public class Vacio extends Estatico{
	
	private Personaje [][] map = Juego.getInstance().getMap();
	private Rockford rockford = Rockford.getInstance();
	
	/**
	 * Constructor Vacio.
	 */
	public Vacio(){
		
	}
	
	/**
	 * Constructor con seteo de posicion.
	 * @param posX: coordenada en X de la pos
	 * @param posY: coordenada en Y de la pos 
	 */
	public Vacio(int posX, int posY){
		super(posX, posY);
	}
	
	
	/**
	 * Establece el comportamiento del personaje al entrar en contacto con Rockford, al ser un Vacio, Rockford puede moverse libremente.
	 *@param nuevaPos: Nueva posicion donde quiere moverse Rockford 
	 */
	public void contactoConRockford(Posicion nuevaPos){	   //Si Rockford entra en contacto con un Vacio, puede avanzar libremente. 
		int xVieja = rockford.getPos().getPosX();			
		int yVieja = rockford.getPos().getPosY();
		int xNueva = nuevaPos.getPosX();
		int yNueva = nuevaPos.getPosY();
				
		rockford.setPos(nuevaPos);				//Muevo a Rockford y pongo Vacio donde se encontraba anteriormente
		map [xNueva][yNueva] = rockford;
		map [xVieja][yVieja] = new Vacio(xVieja, yVieja);
	}
	
	
	/**
	 * Retorna si es un Vacio o no.
	 * @return true: si es un Vacio. False: si no es un Vacio.
	 */
	public boolean esVacio(){
		return true;
	}


}
