package personajes;

import juego.Juego;
/** Clase que representa el comportamiento de un objeto de tipo Roca Estacionaria.
 * 
 * @author ARRECHE-BORINI
 *
 */

public class RocaEstacionaria implements EstadoRoca {
	
	private Rockford rockford = Rockford.getInstance();
	private Personaje [][] map = Juego.getInstance().getMap();
	private boolean turnoRealizado;
	
	
	/**
	 * Establece el comportamiento de una Roca Estacionaria con Rockford . Dependiendo de la direccion en la que se quiera desplazar Rockford 
	 * con respecto a la Roca es el resultado de su ejecucion . Si Rockford se encuentra debajo o encima de la roca, esta permanecera quieta,
	 * en cambio, si Rockford se encuentra a su lado ,  y la roca posee su otro lado libre, ambos se desplazaran.
	 * @param nuevaPosRockford: Nueva posicion donde quiere moverse Rockford 
	 */
	@Override
	public void contactoConRockford(Posicion nuevaPosRockford){
		int comparoX = rockford.getPos().getPosX() - nuevaPosRockford.getPosX();
		
		if (comparoX != 0){													
			if (comparoX > 0){													//ME QUIERO MOVER HACIA LA IZQUIERDA
				int nuevaPosXRoca = nuevaPosRockford.getPosX() - 1;				//TENDRIA QUE CORRER LA ROCA UN CASILLERO A LA IZQ.
				validarCorrimiento(nuevaPosXRoca, nuevaPosRockford);
			}
			else{																//ME QUIERO MOVER HACIA LA DERECHA
				int nuevaPosXRoca = nuevaPosRockford.getPosX() + 1;
				validarCorrimiento(nuevaPosXRoca, nuevaPosRockford);
			}
		}		
	}
	
	
	/**
	 * Encargado de validar el deslizamiento de la roca y por consecuencia el de Rockford.
	 * @param nuevaPosXRoca: Nueva coordenada en X de la Roca que se va a deslizar.
	 * @param nuevaPosRockford: Nueva posicion donde quiere moverse Rockford 
	 */
	private void validarCorrimiento(int nuevaPosXRoca, Posicion nuevaPosRockford){ 		//Si se puede realizar el corrimiento
																							// devuelve true y actualiza tanto la roca como a rockford			
		int posX = rockford.getPos().getPosX();
		int posY = rockford.getPos().getPosY();							//LA POS EN Y ES LA MISMA EN TODOS YA QUE SE MUEVEN SOLO EN X!!
		Posicion posRoca = new Posicion(nuevaPosXRoca, posY);				
		
		if( map[nuevaPosXRoca][posY].esVacio() ){		  		//Si el casillero contiguo esta vacio, voy a poder correr la roca
			
			map[nuevaPosRockford.getPosX()][posY].setPos(posRoca);         			//Seteo la nueva poscion de la roca (nuevaPosRockford es donde actualmente esta la roca)
			map[nuevaPosXRoca][posY] = map[nuevaPosRockford.getPosX()][posY];		//ACTUALIZO LA POS DE LA ROCA Y LA MUEVO
			  			
			rockford.setPos(nuevaPosRockford);
			
			map[nuevaPosRockford.getPosX()][posY] = rockford;						//ACTUALIZO LA POS DE ROCKFORD Y LO MUEVO
			map[posX][posY] = new Vacio(posX, posY);							//AGREGO VACIO DONDE ESTABA ROCKFORD	
		}
	}
	
	
	/**
	 * Encargado de la actualizacion del estado de la Roca en cuestion. Se verifica la situacion en el mapa, 
	 * ya sea si debajo de la roca hay un vacio, si a la izquierda y debajo a la izquierda hay vacios y lo mismo para el lado derecho. 
	 * De acuerdo con ello, la roca cambiar� de estado (en el primer caso) o se deslizar� y cambiar� de estado (segundo
	 * y tercer caso)
	 * @param roca: personaje Roca en cuestion.
	 */
	@Override
	public void actualizarEstado(Roca roca){
		
		if ( !turnoRealizado ){
			turnoRealizado = true;
																				//ES PRIORIDAD SI ABAJO ESTA VACIO, SI NO LO ESTA,											
			int posX = roca.getPos().getPosX();								//SI HAY MURO/DIAMANTE/ROCA, VEO SI SE PUEDE DESPLAZAR,
			int posY = roca.getPos().getPosY();								//SI PUEDE PARA AMBOS LADOS, TIENE PRIORIDAD EL LADO IZQUIERDO
			Posicion nuevaPos;
			
			if ( map[posX][posY + 1].esVacio() ){					//SI ABAJO ESTA VACIO SOLO CAMBIA DE ESTADO
				cambiarEstado(roca);
			}
			
			else{
				if ( ( map[posX][posY + 1].esMuroComun() ) || ( map[posX][posY + 1].esDiamante() ) || ( map[posX][posY + 1].esRoca() ) ){		//SI ABAJO HAY UN MURO, DIAMANTE, O ROCA
					
					if ( ( map[posX-1][posY].esVacio() ) && ( map[posX-1][posY+1].esVacio() ) ){			//DESPLAZO LA ROCA A LA IZQUIERDA
						nuevaPos = new Posicion(posX-1, posY);				
						roca.setPos(nuevaPos);												
						map[posX-1][posY] = roca;
						map[posX][posY] = new Vacio(posX, posY);
						cambiarEstado(roca);	
					}	
					else{
						if ( ( map[posX+1][posY].esVacio() ) && ( map[posX+1][posY+1].esVacio() ) ){			//DESPLAZO LA ROCA A LA DERECHA
							nuevaPos = new Posicion(posX+1, posY);				
							roca.setPos(nuevaPos);												
							map[posX+1][posY] = roca;
							map[posX][posY] = new Vacio(posX, posY);
							cambiarEstado(roca);
						}
					}
				}
			}
		}
	}
	
	
	/**
	 * Setea el estado de la Roca en cuestion a Roca Cayendo.
	 * @param roca: personaje Roca en cuestion.
	 */
	private void cambiarEstado(Roca roca){
		RocaCayendo rocaCayendo = new RocaCayendo();	//CAMBIO EL ESTADO DE ROCA ESTACIONARIA A ROCA CAYENDO
		roca.setEstado(rocaCayendo);						//La roca aun no se mueve, solo cambia de estado
	}
	
	
	public void validarMovimiento(){
		turnoRealizado = false;
	}

}
