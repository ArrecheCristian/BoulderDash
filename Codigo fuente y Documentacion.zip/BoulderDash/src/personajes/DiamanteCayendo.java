package personajes;

import juego.Juego;

/**
 * Clase que define el comportamiento de DiamanteCayendo.
 * @author ARRECHE-BORINI
 */
public class DiamanteCayendo implements EstadoDiamante {
	
	private Personaje [][] map = Juego.getInstance().getMap();
	private Rockford rockford = Rockford.getInstance();
	private boolean turnoRealizado;
	
	/**
	 * @param nuevaPos
	 * Nueva posicion donde quiere moverse Rockford
	 */
	@Override
	public void contactoConRockford(Posicion nuevaPos) {
		//De este contacto se encarga actualizarEstado() de DiamanteCayendo, cuando se fija si tiene a Rockford abajo!
	}
	
	
	/**
	 * Realiza las actualizaciones correspondientes para DiamanteCayendo. Si abajo se encuentra Rockford su trabajo es matarlo, si se encuentra 
	 * un vacio puede caer libremente y cualquier otro objeto lo detiene y solo cambia de estado. 
	 * @param diamante: Personaje Diamante en cuestion
	 */
	@Override
	public void actualizarEstado(Diamante diamante){
		
		if ( !turnoRealizado ){
			turnoRealizado = true;
			Personaje personajeDebajo = map[diamante.getPos().getPosX()][diamante.getPos().getPosY() + 1];
			
			if ( personajeDebajo.esVacio() ){                 
				muevoDiamante(diamante);							//Si abajo esta Vacio, el diamante solo cae
				return ;
			}
			if ( personajeDebajo.esRockford() ){						//Si abajo esta Rockford, este explota y muere
				muevoDiamante(diamante);
				rockford.morir();
				return;
			}
			cambiarEstado(diamante);							//CUALQUIER OTRA COSA SOLO CAMBIA DE ESTADO
		}
	}
	
	
	
	/**
	 * Actualiza la posicion del diamante al caer a una posicion inferior en la coordenada Y.
	 * @param diamante
	 */
	private void muevoDiamante (Diamante diamante){						//El diamante cae un casillero mas abajo 
		int posX = diamante.getPos().getPosX();
		int posY = diamante.getPos().getPosY();
		
		Posicion posNueva = new Posicion(posX, posY + 1);
		diamante.setPos(posNueva);
		map[posX][posY] = new Vacio(posX, posY);
		map[posX][posY + 1] = diamante;            
	}
	
	
	
	/**
	 * Cambia su estado a DiamanteEstacionario
	 * @param diamante
	 */
	private void cambiarEstado (Diamante diamante){							//CAMBIO EL ESTADO DE DIAMANTE CAYENDO A DIAMANTE ESTACIONARIO
																					//aun no se mueve, solo cambia de estado
		DiamanteEstacionario diamanteEstacionario = new DiamanteEstacionario();
		diamante.setEstado(diamanteEstacionario);
	}
	
	public void validarMovimiento(){
		turnoRealizado = false;
	}
	
	
}
