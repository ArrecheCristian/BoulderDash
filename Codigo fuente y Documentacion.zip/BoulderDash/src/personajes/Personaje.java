
package personajes;
/**
 * Clase que representa el compotamiento/atributos de objeto de tipo Personaje.
 * @author ARRECHE-BORINI
 *
 */
public abstract class Personaje {
   
	private Posicion pos;
	
	/**
	 * Constructor Vacio
	 */
	public Personaje(){	
	}
	
	
	/**
	 * Constructor con seteo de posicion 
	 * @param posX: coordenada X de la pos.
	 * @param posY: coordebada Y de la pos.	 
	 */
	public Personaje(int posX, int posY){
		this.pos = new Posicion (posX, posY);
	}
	
	
	public Posicion getPos() {
		return pos;
	}


	public void setPos(Posicion pos) {
		this.pos = pos;
	}

	
   /**
    * Administra el comportamiento del personaje en cuestion cuando
	* entra en contacto con Rockford. Va a ser sobreescrito por cada Personaje.
    * @param nuevaPos
    */
	public void contactoConRockford(Posicion nuevaPos){           
	}
	
	
	/**
	 * Encargado de actualizar el estado actual de un personaje en cuestion.
	 * Cada uno se va a actualizar a su manera segun la sobreescritura del metodo
	 * por la subclase.
	 */
	public void actualizarEstado(){						
	}
	
	
	/**
	 * retorna si es Explosion o no.
	 * @return true si es Explosion. False si no es una explosion.
	 */
	
	public boolean esExplosion(){
		return false;
	}

	/**
	 * retorna si es Roca o no.
	 * @return true si es Roca . False si no es Roca.
	 */																						//cada metodo es...X va a ser sobreescrito en dicho Personaje devolviendo true!
	public boolean esRoca(){
		return false;
	}
	
	/**
	 * retorna si es Vacio o no.
	 * @return true si es Vacio. False si no es Vacio.
	 */
	public boolean esVacio(){
		return false;
	}
	
	/**
	 * retorna si es Rockford o no.
	 * @return true si es Rockford. False si no es Rockford.
	 */
	public boolean esRockford(){
		return false;
	}
	
	/**
	 * retorna si es Puerta o no.
	 * @return true si es Puerta. False si no es Puerta.
	 */
	public boolean esPuerta(){
		return false;
	}
	
	/**
	 * retorna si es Muro  Magico o no.
	 * @return true si es un Muro Magico. False si no es un Muro Magico.
	 */
	public boolean esMuroMagico(){
		return false;
	}
	
	/**
	 * retorna si es Muro de titanio o no.
	 * @return true si es un Muro de Titanio. False si no es un Muro de Titanio.
	 */
	public boolean esMuroTitanio(){
		return false;
	}
	
	/**
	 * retorna si es Muro Comun o no.
	 * @return true si es un Muro Comun. False si no es un Muro Comun.
	 */
	public boolean esMuroComun(){
		return false;
	}
	
	/**
	 * retorna si es Muro Marioposa o no.
	 * @return true si es un Mariposa. False si no es un Mariposa.
	 */
	public boolean esMariposa(){
		return false;
	}
	
	/**
	 * retorna si es Luciernaga o no.
	 * @return true si es Luciernaga. False si no es Luciernaga.
	 */
	public boolean esLuciernaga(){
		return false;
	}
	
	/**
	 * retorna si es Diamante o no.
	 * @return true si es Diamante. False si no es Diamante.
	 */
	public boolean esDiamante(){
		return false;
	}
	
	/**
	 * retorna si es Basura o no.
	 * @return true si es Basura. False si no es Basura.
	 */
	public boolean esBasura(){
		return false;
	}
	
	/**
	 * retorna si es Ameba.
	 * @return true si es Ameba. False si no es Ameba.
	 */
	public boolean esAmeba(){
		return false;
	}
	
	
	/**
	 * Retorna si es un personaje dinamico. 
	 * @return true si es Dinamico. False caso contrario.
	 */
	public boolean esDinamico(){
		return false;
	}
	/**
	 * Valida el movimiento de cada personaje, restringuiendolos a un �nico movimento por turno.
	 */
	public void validarMovimiento(){
		
	}
		
}
