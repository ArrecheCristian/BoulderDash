package personajes;

/**
 * Enum que define las direcciones posibles de movimiento que pueden tomar los PersonajeExplosivos (Luciernaga y Mariposa).
 * @author ARRECHE - BORINI
 */
public enum Direcciones {			//Enumerativos para representar las direcciones de movimiento de Luciernaga y Mariposa
	
	ABAJO, ARRIBA, DERECHA, IZQUIERDA;

}
 
