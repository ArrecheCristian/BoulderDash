package personajes;

import juego.Juego;

/**
 * Clase que define el personaje Explosion.
 * @author ARRECHE - BORINI
 */
public class Explosion extends Dinamico {
	//Definimos la clase Explosion que ser� el objeto creado cuando uno de los personajes explote.
	//Es un objeto que ocupa un unico casillero, por lo tanto nosotros somos los encargados de generar la explosion de 3*3
	
	private int tiempoVida = 10;    //variable que determina el tiempo que dura la explosion antes de colocar vacios
	private boolean porMariposa = false;
	
	/**
	 * Constructor vacio.
	 */
	public Explosion(){
		
	}
	
	
	/**
	 * Constructor con seteo de posicion del personaje Explosion.
	 * @param PosX Coordenada en X de la posicion del objeto.
	 * @param PosY Coordenada en Y de la posicion del objeto.
	 */
	public Explosion(int PosX, int PosY){
		super(PosX,PosY);
	}
	
	public Explosion(int PosX, int PosY, boolean porMariposa){
		super(PosX,PosY);
		this.porMariposa = porMariposa; 				//indica si la explosion fue provocada por una mariposa o no. Si fue consecuencia de 
														//una mariposa, en vez de generar vacios luego de la explosion, genera diamantes.
	}
	
	
	
	/**
	 * Establece el comportamiento del objeto Explosion. Dichos objetos cuentan con un tiempo de vida de 1 segundo. 
	 * Luego, en su lugar, se colocan objetos Vacio o Diamante seg�n corresponda.
	 */
	public void actualizarEstado(){
		Personaje[][] map = Juego.getInstance().getMap();
		
		if( !isTurnoRealizado() ){
			setTurnoRealizado(true);
			if( tiempoVida > 0){
				tiempoVida--;
			}
			else{
				if ( porMariposa ){					//La explosion la provoco una mariposa. Deja diamantes luego de dicha explosion.
					int posX = this.getPos().getPosX();
					int posY = this.getPos().getPosY();
					map[posX][posY] = new Diamante(posX, posY, false);
				}
				else{								//Deja vacios despues de la explosion.
					int posX = this.getPos().getPosX();
					int posY = this.getPos().getPosY();
					map[posX][posY] = new Vacio(posX, posY);
				}
			}
		}
	}
	
	
	/**
	 * Informa si el objeto es una Explosion o no.
	 * @return True si es una Explosion. False caso contrario.
	 */
	public boolean esExplosion(){
		return true;
	}

}
