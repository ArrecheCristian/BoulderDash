package personajes;
/**
 *Clase que define el personaje tipo Diamante, tanto su comportamiento como atributos. 
 * @author ARRECHE-BORINI
 */

public class Diamante extends Dinamico{

	private EstadoDiamante estado;		//patron de dise�o state para definir 2 estados que se comportan de distinta manera
	
	/**
	 * Constructor vacio
	 */
	public Diamante(){
		
	}

	/**
	 * Constructor con seteo de posicion y estado de la roca.
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 * booleano es true si el diamante se encuentra en estado cayendo.
	 */
	public Diamante(int posX, int posY, boolean estaCayendo){
		super(posX, posY);
		if (estaCayendo)
			estado = new DiamanteCayendo();
		else
			estado = new DiamanteEstacionario();
	}
	
	public EstadoDiamante getEstado() {
		return estado;
	}
	
	public void setEstado(EstadoDiamante estado) {
		this.estado = estado;
	}

	
	/**
	 * Ejecuta el comportamiento al entrar en contacto con Rockford, dependiendo el estado actual en el que se encuentra el diamante.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford.
	 */
	public void contactoConRockford(Posicion nuevaPos){
		estado.contactoConRockford(nuevaPos);
	}
	
	
	/**
	 * Actualiza el estado del Diamante, dependiendo el estado en el que se encuentre actualmente(cayendo o estatico). 
	 */
	public void actualizarEstado(){
		estado.actualizarEstado(this);
	}
	
	public void validarMovimiento(){
		estado.validarMovimiento();
	}
	
	/**
	 * Retorna si es un Diamante o no.
	 * @return true si es un Diamante. False si no es un Diamante.
	 */
	public boolean esDiamante(){
		return true;
	}
	 
}
