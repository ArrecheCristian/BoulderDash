package personajes;

import juego.Juego;


/**
 * Clase que se utiliza para definir un comportamiento en com�n tanto para Mariposa como para Luciernaga con sus respectivos atributos. 
 *@author ARRECHE - BORINI
 */
public abstract class PersonajeExplosivo extends Dinamico {		//Clase de la cual heredan Luciernaga y Mariposa al tener practicamente el mismo comportamiento
	
	private Direcciones dirActual;
	
	public Direcciones getDirActual() {
		return dirActual;
	}
	
	public void setDirActual(Direcciones dirActual) {
		this.dirActual = dirActual;
	}

	/**
	 * Constructor vacio.
	 */
	public PersonajeExplosivo(){
		
	}
	
	/**
	 * Constructor con seteo de posicion de PersonajeExplosivo. Tambien setea la direccion inicial que tomar�n dichos personajes.
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 */
	public PersonajeExplosivo(int posX, int posY){
		super(posX, posY);
		dirActual = Direcciones.ARRIBA;  					  //Direccion inicial que toman Mariposa y Luciernaga cuando arranca un nivel
	}
	
	/**
	 * Metodo que realiza la actualizacion tanto de Mariposa como de Luciernaga en cada turno. Si en alguno de los casilleros contiguos a estas
	 * (arriba, abajo, derecha, izquierda) se encuentra Rockford, la Mariposa/Luciernaga en cuesti�n explota y Rockford muere.
	 * Caso contrario, estas buscan moverse en la direccion actual que llevan (solo pueden moverse a trav�s de Vacios).
	 */
	public void actualizarEstado(){
		
		if ( !isTurnoRealizado() ){
			setTurnoRealizado(true);
			Personaje [][] map = Juego.getInstance().getMap();	
		   	Rockford rockford = Rockford.getInstance();
		   	
		   	int posX = this.getPos().getPosX();
		   	int posY = this.getPos().getPosY();
		   	
		   	Personaje personajeArriba = map [posX][posY - 1];
		   	Personaje personajeAbajo = map[posX][posY + 1];
		   	Personaje personajeDer = map[posX + 1][posY];
		   	Personaje personajeIzq = map[posX - 1][posY];
		   	
		   	if ( personajeArriba.esRockford() || personajeAbajo.esRockford() || personajeDer.esRockford() || personajeIzq.esRockford() ){
		   		rockford.morir();							//(Abajo, Arriba, Izquierda o Derecha)
		   		this.explotar();							//Si Rockford esta en alguna de las posiciones contiguas de Luciernaga/Mariposa, esta explota y Rockford muere.
		   	}
		   	else{
		   		 
		   		Direcciones direccionActual = this.getDirActual();
		   		switch (direccionActual){
		   												//Se mueven constantemente tratando de seguir la direccion actual que llevan
		   		case DERECHA : 
		   			movimiento (posX + 1, posY);
		   			break;
		   		 
		   		case ABAJO :
		   			movimiento (posX, posY + 1);
		   			break;
		   		
		   		case IZQUIERDA :
		   			movimiento (posX - 1, posY);
		   			break;
		   			 
		   		case ARRIBA :
		   			movimiento (posX, posY - 1);
		   			break;
		   			 
		   		 } 
		   	}
		}
	}
    
	
	
    /**
     * /**
     * Metodo que se encarga de realizar el movimiento de la Mariposa/Luciernaga en cuesti�n. Siempre se busca seguir la dirreci�n actual que llevan,
     * de no ser posible, cada personaje sobreescribe su propio metodo cambiarDireccin();
     * @param nuevaX: Coordenada en X de la pos.
     * @param nuevaY: Coordenada en Y de la pos.
     */
     
    private void movimiento (int nuevaX, int nuevaY){
    	Personaje[][] map = Juego.getInstance().getMap();
   	 	Posicion nuevaPos = new Posicion(nuevaX, nuevaY);
   	 	int viejaX = this.getPos().getPosX();
   	 	int viejaY = this.getPos().getPosY();				
   	 
   	 	if ( map[nuevaX][nuevaY].esVacio() ){			//Si tienen un Vacio por delante en la direccion actual que llevan, siguen en dicha direccion
   	 		this.setPos(nuevaPos);
   	 		map[nuevaX][nuevaY] = this;
   	 		map[viejaX][viejaY] = new Vacio(viejaX, viejaY);
   	 	}
   	 	else{
   	 		cambiarDireccion();		//Caso contrario, ambas cambian de direccion en distintos sentidos. 
   	 	}
    }
	
    
   /**
    * Metodo sobreescrito en las subclases. Con su comportamiento en espec�fico.
    */
	public void cambiarDireccion(){		//Este metodo esta sobreescrito tanto en Luciernaga como en Mariposa, ya que reaccionan de distinta manera
	}
	
	
	/**
	* Metodo sobreescrito en las subclases. Con su comportamiento en espec�fico.
	*/
	public void explotar(){			//Tambien sobreescrito en Luciernaga y Mariposa ya que se comportan de distinta manera ante una explosion
	}
	
}
