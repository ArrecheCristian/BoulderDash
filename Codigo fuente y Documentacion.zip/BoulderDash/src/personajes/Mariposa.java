package personajes;

import juego.Juego;

/**
 * Clase que define el personaje Mariposa, junto con su correspondiente comportamiento.
 * @author ARRECHE - BORINI
 */
public class Mariposa extends PersonajeExplosivo{
   

	public Mariposa(){
		
	}
	
	/**
	*Constructor con seteo de posicion de Mariposa.
	* @param posX: coordenada en X de la pos.
	* @param posY: coordenada en Y de la pos. 
	*/
	public Mariposa(int posX, int posY){
		super(posX, posY);
	}
   
 
	/**
	 * Retorna si es una Mariposa o no.
	 * @return true si es una Mariposa. False si no es una Mariposa.
	 */
	public boolean esMariposa(){
		return true;
	}
	
	
	
	/**
	 * Se encarga de cambiar la direccion de Mariposa, si es que en la direccion que llevaba no encuentra Vacio. Este cambio
	 * lo realiza en sentido contrario a las agujas del reloj.
	 */
	public void cambiarDireccion(){							// MARIPOSA CAMBIA DIRECCION EN SENTIDO ANTIHORARIO
    	 Direcciones direccionActual = this.getDirActual();
    	 
    	 switch (direccionActual){
    	 case DERECHA :
    		 this.setDirActual(Direcciones.ARRIBA);     //Se sobreescribe el cambiarDireccion() de su clase padre
    		 break;
    	 case ABAJO :
    		 this.setDirActual(Direcciones.DERECHA);
    		 break;
    	 case IZQUIERDA :
    		 this.setDirActual(Direcciones.ABAJO);
    		 break;
    	 case ARRIBA : 
    		 this.setDirActual(Direcciones.IZQUIERDA);
    		 break;
    	 }    	 
     }
	
	
	
	  /**
     * Metodo que representa la explosion de Mariposa cuando muere. Se generan objetos Explosion en un area m�xima de 3*3 (no incluye
     * posiciones donde se encuentre un MuroTitanio), y luego genera Diamantes donde se haya producido dicha explosi�n. 
     */
	public void explotar(){								//Se sobreescribe el explotar() de su clase padre, ya que se compora de distinta manera que Luciernaga
		Personaje[][] map = Juego.getInstance().getMap();
    	Posicion pos = this.getPos(); 
    	
    	int posX= pos.getPosX() - 1;
    	int posY= pos.getPosY() - 1;
 		int x;
 		int y;
 																//Convierte un area de  3*3 (ella en el centro) en Explosion y luego genera Diamantes
 		for ( y = 0; y<3; y++){
    		for ( x = 0; x<3; x++){
    			if ( !map[posX + x][posY + y].esMuroTitanio() )
    				 map[posX + x][posY + y] = new Explosion(posX + x, posY + y, true);
    		}
    	}
    }
	

}
