package personajes;
/**
 * Clase que representa Posiciones en el campo del juego.
 * @author Cristian ARRECHE-BORINI
 *
 */
public class Posicion {
	
	private int posX;
	private int posY;
	
	/**
	 * Constructor vacio
	 */
	public Posicion(){
		
	}
	/**
	 *Constructor con seteo de posicion
	 * @param posX
	 * @param posY
	 *Coordenada en X de la pos
	 *Coordenada en Y de la pos
	 */
	 
	public Posicion (int posX, int posY){
		this.posX = posX;
		this.posY = posY;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	
	
}
