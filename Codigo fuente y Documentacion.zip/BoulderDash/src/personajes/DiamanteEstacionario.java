package personajes;

import juego.Juego;

/**
 * Clase que define el comportamieno de DiamanteEstacionario
 * @author ARRECHE - BORINI
 */

public class DiamanteEstacionario extends Diamante implements EstadoDiamante {
	
	private boolean turnoRealizado;
	
	
	/**
	 * Define el comportamiento de DiamanteEstacionario al entrar en contacto con Rockford. El objetivo es que Rockford sume su cantidad 
	 * de diamantes en 1 y corroborar en cada turno si junto los diamantes necesarios, de ser as�, se habilita la puerta de salida.
	 * @param nuevaPos: Nueva posicion que quiere tomar Rockford
	 */
	@Override
	public void contactoConRockford(Posicion nuevaPos){
		//si rockford entra en contacto con un diamante estacionario, lo tiene que agarrar y avanzar
		
		Personaje [][] map = Juego.getInstance().getMap();
		Rockford rockford = Rockford.getInstance();
		Juego juego = Juego.getInstance();
		
		int xVieja = rockford.getPos().getPosX();
		int yVieja = rockford.getPos().getPosY();
		int xNueva = nuevaPos.getPosX();
		int yNueva = nuevaPos.getPosY();
		
		rockford.setCantDiamantes(rockford.getCantDiamantes() + 1);		 						//Seteo la cant de diamantes que va juntando! 
																								//cuando ya tenga los necesarios, habilito la puerta de salida.
		juego.setPuntajeAcumulado(juego.getPuntajeAcumulado() + juego.getValorDiamante() ); 	//actualizamos el puntaje.
		
		if ( rockford.getCantDiamantes() == rockford.getDiamantesNecesarios() ){				//Rockford ya tomo la cantidad de diamantes minima
			int nuevoValorDiamante = juego.getValorDiamanteBonus();
			juego.setValorDiamante(nuevoValorDiamante); 										//Una vez juntados los diamantes necesarios, comienzan a contar como diamantes bonus.
			int posPuertaX = Puerta.getInstance().getPos().getPosX();
			int posPuertaY = Puerta.getInstance().getPos().getPosY();							//Agrego la puerta al mapa para que Rockford pueda terminar el nivel
			map[posPuertaX][posPuertaY] = Puerta.getInstance();
		}
		rockford.setPos(nuevaPos);		
		map [xNueva][yNueva] = rockford;					//Rockford ya tomo el diamante y avanzo
		map [xVieja][yVieja] = new Vacio(xVieja, yVieja);
	}
	
	
	
	/**
	 * Actualiza DiamanteEstacionario en cada turno. Si abajo tiene Vacio, este solo cambia de estado (a�n no se mueve),
	 * si en la posicion (x-1, y) y (x-1. y+1) inmediatamente a la izquierda e inmediamante a la izquierda abajo respectivamente hay Vacio, 
	 * DiamanteEstacionario se "desliza" a la poscion (x-1, y) y cambia su estado a DiamanteCayendo (a�n no se  mueve). Lo mismo se aplica para
	 * las posiciones corespondientes a la derecha. 
	 * @param diamante
	 */
	@Override
	public void actualizarEstado(Diamante diamante){
		Personaje [][] map = Juego.getInstance().getMap();
		
		if ( !turnoRealizado ){
			turnoRealizado = true;																	
																				//ES PRIORIDAD SI ABAJO ESTA VACIO, SI NO LO ESTA,
			int posX = diamante.getPos().getPosX();								//SI HAY MURO/DIAMANTE/ROCA, VEO SI SE PUEDE DESPLAZAR,
			int posY = diamante.getPos().getPosY();								//SI PUEDE PARA AMBOS LADOS, TIENE PRIORIDAD EL LADO IZQUIERDO
			Posicion nuevaPos;
			
			if ( map[posX][posY + 1].esVacio() ){					//SI ABAJO ESTA VACIO SOLO CAMBIA DE ESTADO
				cambiarEstado(diamante);
			}
			else{
				if ( ( map[posX][posY + 1].esMuroComun() ) || ( map[posX][posY + 1].esDiamante() ) || ( map[posX][posY + 1].esRoca() ) ){		//SI ABAJO HAY UN MURO, DIAMANTE, O ROCA
					
						if ( ( map[posX-1][posY].esVacio() ) && ( map[posX-1][posY+1].esVacio() ) ){			//DESPLAZO EL DIAMANTE A LA IZQUIERDA
							nuevaPos = new Posicion(posX-1, posY);				
							diamante.setPos(nuevaPos);												
							map[posX-1][posY] = diamante;
							map[posX][posY] = new Vacio(posX, posY);
							cambiarEstado(diamante);	
						}
						else{
							if ( ( map[posX+1][posY].esVacio() ) && ( map[posX+1][posY+1].esVacio() ) ){			//DESPLAZO EL DIAMANTE A LA DERECHA
								nuevaPos = new Posicion(posX+1, posY);				
								diamante.setPos(nuevaPos);												
								map[posX+1][posY] = diamante;
								map[posX][posY] = new Vacio(posX, posY);
								cambiarEstado(diamante);
							}
						}
				}
			}
		}
	}
	
	
	/**
	 * Cambia su estado a DiamanteCayendo.
	 * @param diamante
	 */
	private void cambiarEstado(Diamante diamante){
		DiamanteCayendo diamanteCayendo = new DiamanteCayendo();			//CAMBIO EL ESTADO DE DIAMANTE ESTACIONARIO A DIAMANTE CAYENDO
		diamante.setEstado(diamanteCayendo);								//AUN NO SE MUEVE; SOLO CAMBIA DE ESTADO
	}
	
	public void validarMovimiento(){
		turnoRealizado = false;
	}
	

}
