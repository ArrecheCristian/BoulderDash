
package personajes;

import java.util.Random;


import juego.Juego;

/**
 * Clase que define el personaje Ameba , tanto su comportamiento como atributos.
 * @author ARRECHE-BORINI
 */
public class Ameba extends Dinamico {
	
	/** 
	 * Constructor vacio de Ameba
	 */
	public Ameba(){	
	}
	
	/**
	 * Constructor con seteo de posicion de Ameba
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 */
	public Ameba(int posX, int posY){
		super(posX, posY);
	}

	
	/**
	 * retorna si es una ameba o no.
	 * @return true si es una Ameba. False si no es una Ameba.
	 */
	public boolean esAmeba(){
		return true;
	}
	
	
	/**
	 * Ejecuta el comportamiento correspondiente al entrar en contacto con rockford, en este caso Rockford no avanza y la Ameba es inofensiva para �l. .
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford 
	 */
	public void contactoConRockford(Posicion nuevaPos){
	}
	
	
	/**
	 * Obtiene un numero pseudoaleatorio .
	 * @return numero entero. 
	 */
	private int obtenerNumeroRandom(){
													//Obtengo un  numeor random entre 0 y 3 para la direccion de expansion aleatoria de la Ameba
		Random aleatorio = new Random(System.currentTimeMillis());
		int num = (int) aleatorio.nextInt(4);									
		return num;
	}
	
	
	/**
	 * Ejecuta la actualizacion del objeto ameba en cuestion:
	 * Dependiendo del numero pseudoaleatorio obtenido del metodo obtenerNumeroRandom
	 * se expande en una direccion "X" en el campo a traves del metodo expandir.
	 */
	public void actualizarEstado() {
		
		if ( !isTurnoRealizado() ){
			setTurnoRealizado(true);
			
			int random = obtenerNumeroRandom();
			int x = this.getPos().getPosX();
			int y = this.getPos().getPosY();
			
			switch (random){
			case 0 :							// si es 0(cero) expando a la derecha
				expandir(x+1,y);
				break;	
			case 1 :							//si es 1 expando a la izquierda
				expandir(x-1,y);
				break;
			case 2 :							//si es 2 expando hacia abajo
				expandir(x,y+1);
				break;
			case 3 :							//si es 3 expando hacia arriba
				expandir(x,y-1);
				break;
			default : 
				break;
			}
		}
	}
	
	
	
	/**
	 * Si es posible crea una instancia de Ameba en la posicion correspondiente, simulando su expansion sobre el mapa.
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.
	 */
	private void expandir( int nuevaX, int nuevaY) {		//la Ameba se va a expandir, si encuentra un Vacio o Basura en la direccion aleatoria que le toco moverse
															//tiene pocas probabilidades de expandirse en cada turno.
		Personaje[][] map = Juego.getInstance().getMap();
		if ( map[nuevaX][nuevaY].esVacio()  ||  map[nuevaX][nuevaY].esBasura() ){
			map[nuevaX][nuevaY] = new Ameba(nuevaX, nuevaY);
		}
	}
	
}


