package personajes;
/**
 * Clase que representa el comportamiento del tipo de personaje MuroComun
 *@author ARRECHE-BORINI
 */
public class MuroComun extends Estatico{

	
	/**
	 * Constructor vacio
	 */
	public MuroComun(){	
	}
	
	/**
	 *Constructor con seteo de posicion
	 * @param posX: coordenada en X de la pos.
	 * @param posY: coordenada en Y de la pos.	 
	 */
	public MuroComun(int posX, int posY){
		super(posX, posY);
	}
	
	/**
	 *Establece el comportamiento al entrar en contacto con Rockford, al ser un MuroComun no permite el avance de Rockford.
	 * @param nuevaPos: Nueva posicion donde quiere moverse Rockford.
	 */
	public void contactoConRockford(Posicion nuevaPos){
	}
	
	/**
	 * retorna si es una Muro Comun o no.
	 * @return true si es una Muro Comun. False si no es una Muro Comun.
	 */
	public boolean esMuroComun(){
		return true;
		}


}
