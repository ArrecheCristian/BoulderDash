package juego;

import excepciones.ExcepcionFinDeJuego;
import mapa.*;
import personajes.*;

/**
 * Clase restringida a la creacion de un unico objeto (Singleton) utilizada para la representacion del objeto Juego,
 * la cual posee, entre otros m�todos, el m�todo principal para correr el juego.
 * @author ARRECHE-BORINI
 */

public class Juego{

	private static Juego juego;
	private int columna;
	private int fila;
	private Personaje[][] map;
	private BDLevelReader levelReader; 
	private int nivelActual;
	private int valorDiamante;
	private int tiempo;
	private int valorDiamanteBonus;
	private int tiempoEsperaReiniciar = 35;
	private boolean juegoIniciado;
	private int contadorSegundos;
	private int tiempoAcumulado = 0;
	private int puntajeAcumulado = 0;
	
	private int valoresDiamantes [] = {10, 20, 15, 5, 30, 50, 40, 10, 10, 10, 5, 25, 50, 20, 10, 5, 10, 10, 10, 30};  //array donde se guardan los puntajes de cada diamante segun el nivel
	private int tiempos [] = {110, 110, 100, 100, 100, 120, 120, 120, 110, 140, 150, 130, 120, 170, 20, 155, 145, 120, 150, 20}; //array donde se guarda el tiempo correspondiente para cada nivel.
	private int valoresDiamantesBonus [] = {15, 50, 0, 20, 0, 90, 60, 20, 20, 0, 10, 60, 0, 0, 0, 8, 20, 20, 20, 0};	//array donde se guarda el valor de los diamantes bonus.
	
	

	private Juego(){			//Constructor privado para que no se puedan crear m�s de una instancia de Juego, 
								//ya que lo usamos como Singleton, y utilizamos el getInstance();
	}
	
	
	/**
	 * Devuelve la referencia al unico objeto instanciado de la clase Juego. De esta manera se puede acceder a las variables de instancia
	 * de dicha clase desde cualquier lado, sin la necesidad de realizar m�ltiples pasajes de parametros.
	 * @return Referencia a clase Juego.
	 */
	public static Juego getInstance(){
		if (juego == null)
			juego = new Juego();
		return juego;
	}
	
	public void reiniciar() {
		juego = null;
	}
	
	public boolean isJuegoIniciado() {
		return juegoIniciado;
	}

	public void setJuegoIniciado(boolean juegoIniciado) {
		this.juegoIniciado = juegoIniciado;
	}

	public int getValorDiamanteBonus() {
		return valorDiamanteBonus;
	}

	public int getTiempo() {
		return tiempo;
	}

	public int getTiempoAcumulado(){
		return tiempoAcumulado;
	}
	
	public int getTiempoEsperaReiniciar(){
		return tiempoEsperaReiniciar;
	}
	
	public int getPuntajeAcumulado() {
		return puntajeAcumulado;
	}
	
	public void setPuntajeAcumulado(int puntaje) {
		this.puntajeAcumulado = puntaje;
	}

	public int getNivelActual(){
		return nivelActual;
	}

	public int getValorDiamante() {
		return valorDiamante;
	}
	
	public void setTiempoAcumulado(int tiempoAcumulado) {
		this.tiempoAcumulado = tiempoAcumulado;
	}
	
	public void setNivelActual(int nivelActual) {
		this.nivelActual = nivelActual;
	}
	
	public void setValorDiamante(int valorDiamante) {
		this.valorDiamante = valorDiamante;
	}

	public int[] getTiempos(){
		return tiempos;
	}

	public Personaje[][] getMap() {
		return map;
	}

	
	public void crearMapa(){
		levelReader = new BDLevelReader();
		columna = levelReader.getWIDTH();			
		fila = levelReader.getHEIGHT();
		map = new Personaje[columna][fila];
	}
	
	
	  
	/**
	 * Setea el mapa y sus personajes para cada nivel solicitado
	 * en base al archivo levels.xml.
	 * @param nivel: Nivel que corresponda para la configuracion e inicializacion del juego.
	 */
	public void setearNivel(int nivel){	
			BDTile valor;										//variable de "tipo enumerativa " para ir seteando el mapa de Enum otorgado
			int posNivelActual = nivel - 1; 
			
			valorDiamante = valoresDiamantes [posNivelActual];			//inicializo el valor de cada diamante segun el nivel.
			tiempo = tiempos [posNivelActual];					//inicializo el tiempo segun el nivel.
			valorDiamanteBonus = valoresDiamantesBonus[posNivelActual];
			nivelActual = nivel;
			
			try {
				levelReader.readLevels("levels.xml");  				//levanta el archivo
				levelReader.setCurrentLevel(nivel); 		 	//setea el mapa 
				
			} catch (Exception e) {
				e.printStackTrace();
			}					
			for(int y = 0 ; y < fila ; y++ ){         				//mapa de objetos Personaje
				for(int x = 0 ; x < columna ; x++){
					
					valor = levelReader.getTile(x, y);
					switch (valor){								//se crean los objetos con su correspondiente posicion en el mapa
					case EMPTY :
						map[x][y] = new Vacio(x, y);
						break;
					case DIRT :
						map[x][y] = new Basura(x, y);
						break;
					case TITANIUM :
						map[x][y] = new MuroTitanio(x, y);
						break;
					case WALL :
						map[x][y] = new MuroComun(x, y);
						break;
					case ROCK :						
						map[x][y] = new Roca(x, y, false);			//EN FALSE SE CREA EN ESTADO ESTACIONARIO
						break;
					case FALLINGROCK :
						map[x][y] = new Roca(x, y, true);			//EN TRUE SE CREA EN ESTADO CAYENDO 
						break;
					case DIAMOND :					
						map[x][y] = new Diamante(x, y, false);		//ESTADO ESTACIONARIO
						break;
					case FALLINGDIAMOND :						
						map[x][y] = new Diamante(x, y, true);		//ESTADO CAYENDO
					case AMOEBA : 
						map[x][y] = new Ameba(x, y);
						break;
					case FIREFLY :
						map[x][y] = new Luciernaga(x, y);
						break;
					case BUTTERFLY : 
						map[x][y]= new Mariposa(x, y);
						break;
					case EXIT : 
						Puerta puerta = Puerta.getInstance();			//No la agrego al mapa. Solo se va a agregar, cuando se junten la cant de
						map[x][y] = new Basura();						//En el lugar de la puerta asigno un Vacio hasta que �sta sea habilitada
						Posicion posPuerta = new Posicion(x, y);		//diamantes necesarios
						puerta.setPos(posPuerta);
						break;
					case PLAYER :
						Rockford rockford = Rockford.getInstance();
						map[x][y] = rockford;
						Posicion posPlayer = new Posicion(x, y);
						rockford.setPos(posPlayer);
						rockford.setDiamantesNecesarios(levelReader.getDiamondsNeeded());     //CANTIDAD DE DIAMANTES QUE NECESITA SEGUN EL NIVEL
						rockford.setCantDiamantes(0);
						break;
					default: System.out.println("dato erroneo");
					}			
				}
			}
	}
		
	
	
	/**
	* Crea el mapa de objetos Personaje por primera vez, seteandolo en el nivel 1.
	*/
	public void setearNivelInicial(){
		crearMapa();				
		setearNivel(1);
	}
	
	/**
	 * Cuando Rockford muere, se setea el mismo nivel que se encontraba actualmente. 
	 */
	public void setearMismoNivel(){						//Tiempo de espera total hasta que reaparezca Rockford. (tiempoVidaExplosiones + tiempoVidaVacios)
		if ( tiempoEsperaReiniciar > 0 )				//La explosion dura 1 segundo, y luego, durante 3 segundos, quedan vacios hasta que se reinicie el nivel.
			tiempoEsperaReiniciar--;
		else{
			Rockford rockford = Rockford.getInstance();
			tiempoEsperaReiniciar = 35;
			tiempoAcumulado = tiempoAcumulado + (tiempos[nivelActual-1] - tiempo);
			rockford.setMurio(false);
			setearNivel(nivelActual);
		}
	}
	
	
	/**
	 * Cuando el jugador completa un nivel, setea el pr�ximo nivel a jugar. 
	 */
	public void setearProximoNivel(){
		if ( tiempoEsperaReiniciar > 0 )				//La explosion dura 1 segundo, y luego, durante 3 segundos aprox, quedan vacios hasta que se reinicie el nivel.
			tiempoEsperaReiniciar--;
		else{
			Rockford rockford = Rockford.getInstance();
			tiempoEsperaReiniciar = 35;
			puntajeAcumulado = puntajeAcumulado + tiempo;
			nivelActual++;
			tiempoAcumulado = tiempoAcumulado + (tiempos[nivelActual-1] - tiempo);		//tiempo acumulado del jugador. 
			rockford.setCompletoNivel(false);
			setearNivel(nivelActual);
		}
	}
	
	
	
	/**
	* Metodo principal que corre el juego. Su ejecuci�n est� determinada por el Timer. 
	* Cada ronda de juego se ejecutar� 10 veces por segundo. 
	 * @throws ExcepcionFinDeJuego
	 * La excepcion es lanzada si se termino completamente el juego, 
	 * por lo tanto no hay m�s niveles para setear. 
	*/
	public void turnoModelo() throws ExcepcionFinDeJuego {
		Rockford rockford = Rockford.getInstance();
	
		if (tiempo != 0){
			actualizarMapa();
			
			if (rockford.isMurio())
				setearMismoNivel();
			if (rockford.isCompletoNivel()){
				if (nivelActual < 10)
					setearProximoNivel();
				else
					throw new ExcepcionFinDeJuego();
			}
		}
		else{
			if( !rockford.isMurio() )
				rockford.morir();
		}
		if( contadorSegundos < 10)
			contadorSegundos++;
		else{
			tiempo--;
			contadorSegundos = 0;
		}
	}
	
	
	/**
	 * Restringue las actualizaciones de los personajes a un �nico movimiento por turno.
	 */
	public void validarMovimientoPorTurno(){		
		for(int y = 0 ; y < 22 ; y++ ){        
			for(int x = 0 ; x < 40 ; x++){
				
				if (map[x][y].esDinamico())
					map[x][y].validarMovimiento();
			}
		}
	}
	
	
	/**
	* Realiza la actualizacion de los personajes en cada turno. Antes se valida que cada personaje pueda
	* realizar un �nico movimiento por turno.
	*/
	public void actualizarMapa(){
		
		validarMovimientoPorTurno();
		for(int y = 0 ; y < 22 ; y++ ){        
			for(int x = 0 ; x < 40 ; x++){
				
				if( map[x][y].esDinamico() )
					map[x][y].actualizarEstado();
			}
		}
	}
	
	
	
	
}
