package juego;

import grafica.CargarImagenes;
import grafica.VentanaPrincipal;

/**
 * Clase utilizada para testear  la ejecucion del  juego.
 * @author ARRECHE-BORINI
 */
public class Test {
	
	public static void main(String[] args) {
		CargarImagenes.getInstance();
		new VentanaPrincipal();
	}
}
		

