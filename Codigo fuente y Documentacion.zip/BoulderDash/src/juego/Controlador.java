package juego;

import java.util.Timer;
import java.util.TimerTask;
import archivos.Ranking;
import excepciones.ExcepcionFinDeJuego;
import grafica.InscripcionJugador;
import grafica.Pantalla;
import personajes.Rockford;

public class Controlador extends TimerTask {
	
	private Timer timer;
	
	public void setTimer(Timer timer) {
		this.timer = timer;
	}
	
	public void cancelarTimer(){
		timer.cancel();
	}
	
	
	public void run(){
		Juego juego = Juego.getInstance();
		Pantalla pantalla = Pantalla.getInstance();
		Rockford rockford = Rockford.getInstance();
		
		if( (rockford.getVidas() > 0)){
			try {
				juego.turnoModelo();
			} catch (ExcepcionFinDeJuego e) {
				timer.cancel();
				e.juegoTerminado();
				controlarRanking();
			}
			pantalla.turnoGrafica();
		}
		else{
				timer.cancel();
				controlarRanking();
		}
	}
	
	
	public void controlarRanking(){
		Juego juego = Juego.getInstance();
		Ranking ranking = Ranking.getInstance();
		
		juego.setTiempoAcumulado(juego.getTiempoAcumulado() + (juego.getTiempos()[juego.getNivelActual()-1] - juego.getTiempo()));
		int posicion = ranking.evaluarJugador(juego.getPuntajeAcumulado(), juego.getTiempoAcumulado());
		
		if(ranking.isAgregar())
			new InscripcionJugador(posicion);
	}
}
