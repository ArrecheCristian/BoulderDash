package grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import excepciones.ExcepcionImagenNoEncontrada;
import juego.Juego;
import personajes.Rockford;

public class DiamantesDatos extends JPanel{
	
	private Casillas[] numerosGraficos = new Casillas[5];
    private ImageIcon imagenDiamante;
    
    
	public DiamantesDatos(){
		FlowLayout mylayout = new FlowLayout();
		mylayout.setHgap(0);
		this.setLayout(mylayout);
		this.setPreferredSize(new Dimension(200,30));
		this.setBackground(Color.black);
		
		for(int i=0; i<5; i++){
			numerosGraficos[i] = new Casillas();
			numerosGraficos[i].setPreferredSize(new Dimension(30,20));
			this.add(numerosGraficos[i]); 	
		}
		CargarImagenes aux = CargarImagenes.getInstance();
		numerosGraficos[2].setImagen(aux.getDiamanteEstatico());
		actualizarInformacionDiamante(); 	
	}
	
	
	
	public void actualizarInformacionDiamante(){ 
		
		Rockford rockford = Rockford.getInstance();
		Juego juego = Juego.getInstance();
		CargarImagenes aux = CargarImagenes.getInstance();
		    
		int diamantesNecesarios = rockford.getDiamantesNecesarios();
		numerosGraficos[0].setImagen(aux.getNumerosAmarillos(diamantesNecesarios/10));
		numerosGraficos[1].setImagen(aux.getNumerosAmarillos(diamantesNecesarios%10));
		   
		int valorDiamante = juego.getValorDiamante(); 
		numerosGraficos[3].setImagen(aux.getNumerosBlancos(valorDiamante/10));
		numerosGraficos[4].setImagen(aux.getNumerosBlancos(valorDiamante%10));
		   
		repaint();
	}
	 

	    
	    
	 
	 
	 

}
