package grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import archivos.Configuracion;
import archivos.Jugador;
import archivos.Ranking;

public class TopX extends JFrame{
	
	private JTable tabla;
	private String[]  titulos = {"PUESTO #", "NOMBRE", "PUNTOS", "TIEMPO"};
	private boolean abierto;
	
	public boolean isAbierto() {
		return abierto;
	}

	public void setAbierto(boolean abierto) {
		this.abierto = abierto;
	}

	public TopX(){
		Ranking ranking = Ranking.getInstance();
		
		abierto = true;
		Jugador[] jugadores = ranking.getJugadores();
		Configuracion configuracion = Configuracion.getInstance();
		configuracion.leerConfiguracion();
		int filasVisibles = configuracion.getTopVisible();
		
		Object[][] tablaJugadores = new Object[filasVisibles][4];
		
		for(int i=0 ; i<filasVisibles ;i++){
			tablaJugadores[i][0] = jugadores[i].getPuesto();
			tablaJugadores[i][1] = jugadores[i].getNombre();
			tablaJugadores[i][2] = jugadores[i].getPuntos();
			tablaJugadores[i][3] = jugadores[i].getTiempo();	
		}
		//TABLA
		tabla = new JTable();
		tabla.setModel(new DefaultTableModel(tablaJugadores, titulos){
			private static final long serialVersionUID = 1L;
			
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}		
		});
		
		tabla.setBackground(Color.BLUE);
		tabla.setForeground(Color.WHITE);
		tabla.setRowHeight(28);
		
		//MARCO
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				setVisible (false);
				abierto = false;
			}
		});
		
		setLayout(new BorderLayout());
		setTitle("Ranking tiempo real");
		setResizable(false);
		setBounds(400, 100, 700, 250);		
		add(new JScrollPane(tabla), BorderLayout.CENTER);
		setVisible(true);
	}
	

}
