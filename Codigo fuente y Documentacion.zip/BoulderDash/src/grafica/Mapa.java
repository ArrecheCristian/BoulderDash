package grafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import juego.Juego;
import personajes.Personaje;
import personajes.Rockford;

public class Mapa extends JPanel {
	
	private Casillas [][] casillas = new Casillas[40][22];
	private int movActualRockford = 0;
    

	public Mapa() {
		setLayout(new GridLayout(22, 40));
    	setBackground(new Color(0, 0, 0)); 				
        setFocusable(true);
        addKeyListener(new MovimientoTeclado());        
    }
    

    public void crearMapaGrafico(){						//Se crea el mapa una unica vez cuando comienza el juego.
		int x, y;
		for(y = 0; y < 22; y++){
			for(x = 0; x < 40; x++){
				casillas[x][y] = new Casillas();
				add(casillas[x][y]);
			}
		}
		actualizarMapaGrafico();
    }
    
    
	public void actualizarMapaGrafico(){						//se setea el mapa segun corresponda en cada turno de la grafica
		CargarImagenes aux = CargarImagenes.getInstance();	
		Personaje[][] mapa = Juego.getInstance().getMap();
		int x, y;
			
		for(y = 0; y < 22; y++){
			for(x = 0; x < 40; x++){
			
				if(mapa[x][y].esAmeba())
					casillas[x][y].setImagen(aux.getAmeba());
				
				if (mapa[x][y].esBasura())
					casillas[x][y].setImagen(aux.getBasura());
				
				if(mapa[x][y].esDiamante())
					casillas[x][y].setImagen(aux.getDiamante());
				
				if(mapa[x][y].esExplosion())
					casillas[x][y].setImagen(aux.getExplosion());  
				
				if(mapa[x][y].esLuciernaga())
					casillas[x][y].setImagen(aux.getLuciernaga());
				
				if(mapa[x][y].esMariposa())
					casillas[x][y].setImagen(aux.getMariposa());
				
				if(mapa[x][y].esMuroComun())
					casillas[x][y].setImagen(aux.getMuro());
				
				if(mapa[x][y].esMuroMagico())
					casillas[x][y].setImagen(aux.getMuroMagico());
				
				if(mapa[x][y].esMuroTitanio())
					casillas[x][y].setImagen(aux.getMuroTitanio());
				
				if(mapa[x][y].esPuerta())
					casillas[x][y].setImagen(aux.getPuerta());
				
				if(mapa[x][y].esRoca())
					casillas[x][y].setImagen(aux.getRoca());
				
				if(mapa[x][y].esRockford()){
					casillas[x][y].setImagen(aux.getMovimientoRockford(movActualRockford));
					movActualRockford = 0;
				}
	
				if(mapa[x][y].esVacio())
					casillas[x][y].setImagen(aux.getVacio());
			}
		}
		repaint();
	}
	
    
	public class MovimientoTeclado extends KeyAdapter{
		
		public void keyPressed(KeyEvent evento){
			Rockford rockford = Rockford.getInstance();
			
			if( !rockford.isMurio() && !rockford.isCompletoNivel() ){					//Si rockford muere, logicamente no puede moverse.
				int movimiento = evento.getKeyCode();
				
				if (movimiento == 37){					//IZQUIERDA
					rockford.setDireccion(4);
					movActualRockford = 1;
				}
				if (movimiento == 38){					//ARRIBA
					rockford.setDireccion(8);
					movActualRockford = 2; 
				}
				if (movimiento == 39){					//DERECHA
					rockford.setDireccion(6);
					movActualRockford = 2;
				}
				if ( movimiento == 40){					//ABAJO
					rockford.setDireccion(2);
					movActualRockford = 2;
				}
			}
		}
	}
    
    
    
}  
    
    