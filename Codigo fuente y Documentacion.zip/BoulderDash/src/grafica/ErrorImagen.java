package grafica;

import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ErrorImagen {
	private JButton boton;
	
	public ErrorImagen(){
		
		JOptionPane.showMessageDialog(
				null, 
				"La gr�fica no pudo ser cargada correctamente debido a que hubo imagenes que no fueron encontradas.\nVerifique los problemas y vuelva a intentarlo.", //mensaje
				"Error Gr�fico", //tipo de opci�n
				JOptionPane.ERROR_MESSAGE);
	}
}
