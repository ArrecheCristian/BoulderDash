package grafica;

import java.awt.*;
import javax.swing.*;

public class Casillas extends JPanel{
    	
        private ImageIcon imagen;    
        
        public Casillas() {
        }
        
        public void setImagen(ImageIcon imagen){
            this.imagen = imagen;
        }
        
        public ImageIcon getImagen(){        
            return this.imagen;
        }
        
        public void paintComponent(Graphics g){ 
        	super.paintComponent(g);
            g.drawImage(imagen.getImage(), 0,0,this.getWidth(),this.getHeight(),this);
        }
 }