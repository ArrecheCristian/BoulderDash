package grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import personajes.Rockford;

public class DiamantesContador extends JPanel{
	
	private Casillas[] digitosCantDiamantes = new Casillas[2];
	private int contadorDiamantes;
	private CargarImagenes aux = CargarImagenes.getInstance();
	private int cache = -1;

	public DiamantesContador(){
		FlowLayout mylayout = new FlowLayout();
		mylayout.setHgap(0);
		this.setLayout(mylayout);
		this.setBackground(Color.black);
		this.setPreferredSize(new Dimension(90,30));
		
		for(int i=0; i<2; i++){
			digitosCantDiamantes[i] = new Casillas();
			digitosCantDiamantes[i].setPreferredSize(new Dimension(30,20));
			add(digitosCantDiamantes[i]);
		}
		actualizarContador();
	}

	public void actualizarContador(){				
		contadorDiamantes = Rockford.getInstance().getCantDiamantes();

		if (contadorDiamantes != cache){
			cache = contadorDiamantes;
			digitosCantDiamantes[0].setImagen(aux.getNumerosAmarillos(contadorDiamantes/10));
			digitosCantDiamantes[1].setImagen(aux.getNumerosAmarillos(contadorDiamantes%10));
			repaint();
		}
	}
	

}
    
    
    
    
    
    