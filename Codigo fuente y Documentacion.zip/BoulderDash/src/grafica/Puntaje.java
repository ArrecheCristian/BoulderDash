package grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import juego.Juego;


public class Puntaje extends JPanel{
	
	private Casillas[] numerosPuntaje = new Casillas[6];
	private CargarImagenes aux = CargarImagenes.getInstance();
	private int cache = -1;


	public Puntaje (){
		FlowLayout mylayout = new FlowLayout();
		mylayout.setHgap(0);
		this.setLayout(mylayout);
		this.setPreferredSize(new Dimension(200,30));
		this.setBackground(Color.black);
		
		for(int i=0; i<6; i++){
			numerosPuntaje[i] = new Casillas();
			numerosPuntaje[i].setPreferredSize(new Dimension(30,20));
		    setearImagen(i,aux.getNumerosBlancos(0));
		}
	}

	
	private void setearImagen(int pos, ImageIcon imag){
		numerosPuntaje[pos].setImagen(imag);
		this.add(numerosPuntaje[pos]);		
	}
	
	
	public void actualizarPuntaje(){
		
		int puntaje = Juego.getInstance().getPuntajeAcumulado();
		
		if( puntaje != cache ){
			cache = puntaje;
			
			numerosPuntaje[5].setImagen(aux.getNumerosBlancos(puntaje%10));
			puntaje = puntaje/10;
			numerosPuntaje[4].setImagen(aux.getNumerosBlancos(puntaje%10));
			puntaje = puntaje/10;
			numerosPuntaje[3].setImagen(aux.getNumerosBlancos(puntaje%10));
			puntaje = puntaje/10;
			numerosPuntaje[1].setImagen(aux.getNumerosBlancos(puntaje%10));
			puntaje = puntaje/10;
			numerosPuntaje[0].setImagen(aux.getNumerosBlancos(puntaje%10));
			
			this.repaint();
		}
	}


	
	

}
