package grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import juego.Juego;

public class Reloj extends JPanel{
	
	private Casillas[] digitosReloj = new Casillas[3];
	private int unidad = 0;
	private int decena = 0;
	private int centena = 0;
	private CargarImagenes loader = CargarImagenes.getInstance();
	private int contadorSegundos = 0;

	
	public Reloj(){
		FlowLayout mylayout = new FlowLayout();
		mylayout.setHgap(0);
		this.setLayout(mylayout);
		this.setBackground(Color.black);
		this.setPreferredSize(new Dimension(110,30));
		this.setMaximumSize(getMaximumSize());;
		this.setMinimumSize(getMinimumSize());
		
		for(int i=0; i<3; i++){
			digitosReloj[i] = new Casillas();
			digitosReloj[i].setPreferredSize(new Dimension(30,20));
		}
		inicializarReloj();	
		setearImagen(2, loader.getNumerosBlancos(centena));
		setearImagen(1, loader.getNumerosBlancos(decena));
		setearImagen(0, loader.getNumerosBlancos(unidad));	
	}
	
	
	private void setearImagen(int pos, ImageIcon imag){
		digitosReloj[pos].setImagen(imag);
		add(digitosReloj[pos]);		
	}
	
	
	public void inicializarReloj() {  
		int tiempo = Juego.getInstance().getTiempo();
		if(tiempo > 0){
			
	    	unidad = tiempo%10;
	    	digitosReloj[0].setImagen(loader.getNumerosBlancos(unidad));
	    	
	    	tiempo = tiempo/10;
	    	decena  = tiempo%10;
	    	digitosReloj[1].setImagen(loader.getNumerosBlancos(decena));
	    	
	    	tiempo = tiempo/10;
	    	centena = tiempo%10;
	    	digitosReloj[2].setImagen(loader.getNumerosBlancos(centena));
	    	repaint();
		}
	}
	 
	
	 public void actualizarReloj(){
		 
		 if( contadorSegundos == 10){
			 contadorSegundos = 0;	
			 if ( unidad > 0 ){
				 unidad--;
				 digitosReloj[0].setImagen(this.loader.getNumerosBlancos(unidad));	//decremento solo unidades
			 }
			 else{
				 if (decena > 0){ 										//reinicio unidades y aumento decenas
					 unidad = 9;
					 decena--;
					 digitosReloj[0].setImagen(this.loader.getNumerosBlancos(unidad));
					 digitosReloj[1].setImagen(this.loader.getNumerosBlancos(decena));
				 }
				 else{
					 if(centena > 0){
						 unidad = 9;										//reinicio unidades y decenas y aumento centena
						 decena = 9;
						 centena--;
						 digitosReloj[0].setImagen(this.loader.getNumerosBlancos(unidad));
						 digitosReloj[1].setImagen(this.loader.getNumerosBlancos(decena));
						 digitosReloj[2].setImagen(this.loader.getNumerosBlancos(centena));
					 }
				 }
			 }	
			 this.repaint();
		 }
		 else{
			 contadorSegundos++;
		 }
	}
	
	
}