package grafica;

import javax.swing.*;
import archivos.Configuracion;
import juego.Controlador;
import juego.Juego;
import java.util.Timer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class VentanaPrincipal extends JFrame{
	private JButton reglas; 					// Declaramos las componentes Button
	private JButton quieroJugar;
	private JButton topX;
	private JButton config;

	
	public VentanaPrincipal() {
		CargarImagenes loader = CargarImagenes.getInstance();
		
		quieroJugar = new JButton("Jugar");
		quieroJugar.setForeground(Color.WHITE);
		quieroJugar.setFont(new Font("Arial", Font.ITALIC, 20));
		quieroJugar.setContentAreaFilled(false);
		quieroJugar.setBorder(null);
		quieroJugar.setBounds(440, 200, 85, 20);
		quieroJugar.addMouseListener(new JuegoActionListener());
		
		reglas = new JButton("Reglas");
		reglas.setFont(new Font("Arial", Font.ROMAN_BASELINE, 20));
		reglas.setForeground(Color.LIGHT_GRAY);
		reglas.setContentAreaFilled(false);;
		reglas.setBorder(null);		
		reglas.setBounds(433, 230, 100, 20);
		reglas.addMouseListener(new ReglasActionListener());
		
		topX = new JButton("Ranking");
		topX.setFont(new Font("Arial", Font.ITALIC, 20));
		topX.setForeground(Color.GRAY);
		topX.setContentAreaFilled(false);
		topX.setBorder(null);		
		topX.setBounds(427, 260, 115, 20);
		topX.addMouseListener(new TopActionListener());
		
		config = new JButton("Configuracion");
		config.setFont(new Font("Arial", Font.ITALIC, 20));
 		config.setForeground(Color.DARK_GRAY);
 		config.setContentAreaFilled(false);
		config.setBorder(null);		
        config.setBounds(420, 290, 130, 20);
		config.addMouseListener(new ConfigActionListener());

		Casillas casilla = new Casillas();
		casilla.setImagen(loader.getPantallaInicio());
		casilla.setLayout(null);
		casilla.add(config);
		casilla.add(quieroJugar);
		casilla.add(topX);
		casilla.add(reglas);
		casilla.repaint();
		
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setTitle("Men� Principal");		
	    this.setResizable(false);
		this.setLayout(new BorderLayout());
		this.add(casilla,BorderLayout.CENTER);
		this.setBounds(300, 80, 700, 500);
		this.setVisible(true);				
	}
	
	
	
	private class ReglasActionListener extends MouseAdapter {
		boolean creado = false;
		private JLabel label;
		private JFrame frame;
		
		@Override
		public void mouseClicked(MouseEvent e) {
			if(!creado){
				creado = true;
				frame = new JFrame("Boulder Dash: Reglas del juego");
				
				String texto = "<html><body> <i> 1.  Del juego en s� (objetivo): </i> <br><br>"
						+ "-   Cada nivel es completado con �xito cuando el personaje principal, Rockford, logra alcanzar la puerta de salida.<br>  "
						+ "-   La puerta de salida s�lo ser� habilitada si Rockford encuentra una cantidad determinada de diamantes "
						+ "en determinado tiempo. Ambos parametros var�an seg�n el nivel.<br>"
						+ "-   Cada nivel puede jugarse empleando un m�ximo de 4 vidas.<br><br><br>"
						+ "<i> 2.  Los Personajes: </i> <br><br>"
						+ "Los casilleros con rocas o muros no son accesibles para Rockford. Mientras que los casilleros con suciedad o vac�os SI son accesibles para �l,"
						+ " y de hecho har� su camino a trav�s de estos.<br><br>"
						+ "<i>Rockford:</i> es el personaje principal, debe recorrer el laberinto tratando de juntar una cantidad m�nima de diamantes que le habiliten la puerta de salida "
						+ "al pr�ximo nivel. <br>Puede escarbar en la basura as� como empujar las rocas, las cuales se desplazar�n s�lo si el casillero contiguo est� vac�o.<br><br>"
						+ "<i>Rocas:</i> Si una roca est� actualmente �cayendo� y en el casillero justo debajo se encuentra Rockford, el jugador explota y muere.<br><br>"
						+ "<i>Diamantes:</i> Si un diamante est� actualmente �cayendo� y en el casillero justo debajo se encuentra Rockford, el jugador explota y muere.<br><br>"
						+ "<i>Luci�rnaga:</i> Si el jugador se encuentra en uno de los cuatro casilleros vecinos adyacentes a la luci�rnaga "
						+ "(arriba abajo, izquierda o derecha), la luci�rnaga explota y el jugador muere. <br>De otro modo, la luci�rnaga solo trata de moverse.<br><br>"
						+ "<i>Mariposa:</i> Las mariposas se comportan de la misma manera que las luci�rnagas.<br><br>"
						+ "<i>Ameba:</i> La ameba no se mueve y su toque es inofensivo, pero esta lentamente se va expandiendo por los casilleros vac�os,"
						+ " haciendo que el jugador no pueda moverse por esos casilleros.<br><br>"
						+ "Muro de Titanio: Es un muro indestructible.<br><br>"
						+ "<i>Muro M�gico:</i> Es un tipo especial de muro que permite convertir rocas en diamantes y viceversa s�lo durante un tiempo determinado.<br><br>"
						+ "<i>Basura:</i> Rockford escarba a trav�s de la basura para dejar espacios vac�os.<br><br>"
						+ "<i>Puerta de Salida:</i> �sta se habilita cuando Rockford pudo recolectar una determinada cantidad de diamantes.<br><br><br>";
				
				label = new JLabel(texto);
				label.setSize(500,500);
				
				frame.add(new JScrollPane(label));
				frame.setBounds(200, 100, 1150, 500);
				frame.setDefaultCloseOperation(HIDE_ON_CLOSE);
				frame.setVisible(true);
			}
			else
				frame.setVisible(true);	
			}
	}
	
	
	private class JuegoActionListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			
			Juego juego = Juego.getInstance();
			if( !juego.isJuegoIniciado() ){
				juego.setJuegoIniciado(true);
				
				Timer timer = new Timer();
				Controlador controlador = new Controlador();
				controlador.setTimer(timer);
				
				juego.setearNivelInicial();
				Pantalla.getInstance().controladorTimer(controlador);	//Se carga el mapa del juego listo para jugar77muestro la pantalla
				timer.schedule(controlador, 300, 100);
			}
		}
	}
	
	
	private class TopActionListener extends MouseAdapter {	 
		boolean abierto = false;
		TopX top;
		
		@Override
		public void mouseClicked(MouseEvent e) {
			if (!abierto){
				top = new TopX();
				abierto = true;
			}
			else{							//Para que no se puedan seguir abriendo infinitas ventanas. Si hay abierta una, se muestra unicamente esa.
				if(!top.isAbierto())
					top = new TopX();
				else
					top.setVisible(true);
			}
		}

	}
	
	
	private class ConfigActionListener extends MouseAdapter {
		private JList lista;
		private JLabel top;
		private JLabel mensaje;
		private boolean creado = false;
		private JFrame frame;
		
		@Override
		public void mouseClicked(MouseEvent e) {
			if ( !creado ){
				creado = true;
				
				String[] opciones = { "5", "10", "15", "20" };
				lista = new JList(opciones);
				lista.setVisibleRowCount(4);
				
				JButton botonGuardar = new JButton("Guardar");
				botonGuardar.addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent arg0) {
						Configuracion configuracion = Configuracion.getInstance();
						String x = (String) lista.getSelectedValue();
						int topVisible = Integer.parseInt(x);
						configuracion.setTopVisible(topVisible);
						configuracion.guardarConfiguracion();
						frame.setVisible(false);
					}
				});
				
				mensaje = new JLabel("Seleccione la configuracion del ranking que desee: ");
				top = new JLabel("Mostrar TOP: ");

				frame = new JFrame("Boulder Dash: Configuracion");
				frame.setBounds(500, 200, 370, 180);
				frame.setLayout(new FlowLayout());
				frame.setResizable(false);
				frame.add(mensaje);
				frame.add(top);
				frame.add(lista);
				frame.add(botonGuardar);
				frame.setVisible(true);
			}
			else
				frame.setVisible(true);
		}
	}
	
	
	
}

