package grafica;

import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JPanel;


public class BarraDatos extends JPanel {
	
	private Reloj reloj;
	private DiamantesDatos diamantesDatos;
	private DiamantesContador diamantesContador;
	private Puntaje puntaje;
	

	public BarraDatos(){
		FlowLayout myLayout = new FlowLayout();
		myLayout.setHgap(100);
		setLayout(myLayout);
		setBackground(Color.BLACK);
		
	    diamantesDatos = new DiamantesDatos();
		add(diamantesDatos);
		
		reloj = new Reloj();
		add(reloj);
		
		diamantesContador = new DiamantesContador();
		add(diamantesContador);
		
		puntaje = new Puntaje();
		add(puntaje);	
	}
	
	
	public void actualizarBarraDatos(){
		reloj.actualizarReloj();
		puntaje.actualizarPuntaje();
		diamantesDatos.actualizarInformacionDiamante();
		diamantesContador.actualizarContador();
	}

	
	public void inicializarReloj(){
		reloj.inicializarReloj();
	}
	
	public void actualizarInformacionDiamante(){
		diamantesDatos.actualizarInformacionDiamante();
	}
	
}
