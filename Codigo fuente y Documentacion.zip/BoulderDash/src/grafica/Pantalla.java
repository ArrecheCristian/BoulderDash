package grafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import juego.*;
import personajes.Rockford;

public class Pantalla extends JFrame {
	
	private static Pantalla pantalla;
	private Mapa mapaGrafico;
	private BarraDatos barraDatos;
	private Controlador controladorTimer;
	private boolean reinicioReloj;
	private int tiempoEspera = Juego.getInstance().getTiempoEsperaReiniciar();
	
	
	public static Pantalla getInstance(){
		if (pantalla == null)
			pantalla = new Pantalla();	
		return pantalla;
	}
	
	
	public void reiniciar() {
		pantalla = null;
	}
	
	public void controladorTimer(Controlador controladorTimer){
		this.controladorTimer = controladorTimer;
	}


	private Pantalla(){		
		barraDatos = new BarraDatos();
		mapaGrafico = new Mapa();
		mapaGrafico.crearMapaGrafico();
		
		this.setLayout(new BorderLayout());
		this.setTitle("Boulder Dash");
		this.add(barraDatos, BorderLayout.NORTH);	
		this.add(mapaGrafico, BorderLayout.CENTER);
		this.setBounds(250, 50, 1100, 600);
		this.addWindowListener(new MyWindowAdapter());
		this.setVisible(true);
	}
	
	
	public void turnoGrafica(){
		Rockford rockford = Rockford.getInstance();		
		
		mapaGrafico.actualizarMapaGrafico();
		barraDatos.actualizarBarraDatos();
		
		if ( (rockford.isCompletoNivel()) || (rockford.isMurio()) )
			reinicioReloj = true;
		
		if(reinicioReloj){
			if( tiempoEspera > 0)
				tiempoEspera--;
			else{
				inicializarPantalla();
				reinicioReloj = false;
				tiempoEspera = 25;
			}
		}
	}
	
	
	private void inicializarPantalla(){    	
		barraDatos.actualizarInformacionDiamante();
		barraDatos.inicializarReloj();
	}
	
	
	public class MyWindowAdapter extends WindowAdapter{

		public void windowClosing(WindowEvent e) {
			pantalla.setVisible(false);
			controladorTimer.cancelarTimer();
			pantalla.reiniciar();
			Rockford.getInstance().reiniciar();
			Juego.getInstance().reiniciar();	
		}
	}
	
	
	
}
