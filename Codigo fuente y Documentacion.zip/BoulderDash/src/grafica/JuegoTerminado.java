package grafica;

import javax.swing.*;
import excepciones.ExcepcionImagenNoEncontrada;
import java.awt.*;

public class JuegoTerminado extends JFrame{
	
	public JuegoTerminado(){
		
		Casillas casilla = new Casillas();
		CargarImagenes aux = CargarImagenes.getInstance();
		casilla.setImagen(aux.getJuegoTerminado());
		
		JPanel panel = new JPanel();
		panel.setSize(500, 500);
		panel.setLayout(new BorderLayout());
		panel.add(casilla, BorderLayout.CENTER);	
		
		
		add(panel);
		setTitle("Juego terminado con �xito.");
		setBounds(500, 100, 500, 500);
		setVisible(true);
	}
}
