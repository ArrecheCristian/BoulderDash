package grafica;

import javax.swing.*;

import archivos.Jugador;
import archivos.Ranking;
import juego.Juego;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InscripcionJugador extends JFrame{
	
	JTextField campoTexto;
	JButton boton;
	String nombre;
	JLabel mensaje;
	private int posicion;
	
	public InscripcionJugador(int posicion){	
		this.posicion = posicion;
		
		//CAMPO DE TEXTO
		campoTexto = new JTextField(20);

		//BOTON
		boton = new JButton("Guardar");
		boton.setBounds(175, 185, 50, 30);
		boton.addMouseListener(new MyMouseListener());	
		
		//LABEL
		mensaje = new JLabel("<html><body> Su partida est� entre las 20 mejores.<br>Ingrese su nombre si desea guardarla");
		mensaje.setFont(new Font("", Font.TRUETYPE_FONT, 13));
		
		//MARCO
		setTitle("Guardar Partida");
		setBounds(500, 200, 300, 150);
		setLayout(new FlowLayout());
		setResizable(false);
		add(mensaje);
		add(campoTexto);
		add(boton);
		setVisible(true);
	}


	public String getNombre(){
		return nombre;
	}
	
	
	public class MyMouseListener extends MouseAdapter{
		public void mouseClicked(MouseEvent e){
			String nombreAux = campoTexto.getText();
			
			corroborarNombre(nombreAux);
		}
	}

	
	private boolean corroborarNombre(String nombreAux){
		Ranking ranking = Ranking.getInstance();
		Jugador[] jugadores = ranking.getJugadores();
		Juego juego = Juego.getInstance();
		
		JLabel mensaje = new JLabel("<html><body>-El nombre debe contener al menos 2 caracteres.<br>-El nombre no puede contener espacios en blanco. ");
		mensaje.setFont(new Font("", Font.PLAIN, 12));
		
		JLabel mensaje2 =  new JLabel("<html><body>-Reintente con otro nombre. ");
		mensaje2.setFont(new Font("", Font.PLAIN, 12));
		
		char[] caracteres = nombreAux.toCharArray();
	
		for(int i=0; i<nombreAux.length(); i++){
			if (caracteres[i] == ' '){
				JOptionPane.showMessageDialog(null, mensaje, "Nombre inv�lido", JOptionPane.ERROR_MESSAGE); 
				return false;
			}
		}		
		if( ( nombreAux.length() < 2) ){
			JOptionPane.showMessageDialog(null, mensaje, "Nombre inv�lido", JOptionPane.ERROR_MESSAGE); 
			return false;
		}		
		for(int i=0; i<20; i++){
			if(nombreAux.equals(jugadores[i].getNombre())){
				JOptionPane.showMessageDialog(null, mensaje2, "Nombre Existente", JOptionPane.ERROR_MESSAGE); 
				return false;
			}
		}
		
		if(nombreAux.length() > 20)
			nombreAux = nombreAux.substring(0,20);
		
		nombre = nombreAux;
		ranking.nuevoJugador(posicion, nombre, juego.getPuntajeAcumulado(), juego.getTiempoAcumulado());
		setVisible(false);
		return true;
		}
	
}
