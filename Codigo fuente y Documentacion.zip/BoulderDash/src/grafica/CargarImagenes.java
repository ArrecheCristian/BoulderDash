package grafica;

import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import excepciones.ExcepcionImagenNoEncontrada;



public class CargarImagenes extends JPanel {	
	
	private static CargarImagenes auxiliar;
	private ImageIcon [] numerosBlancos = new ImageIcon[10];
	private ImageIcon [] numerosAmarillos = new ImageIcon[10];
	private ImageIcon [] movimientoRockford = new ImageIcon[3];	
	private ImageIcon muro;
    private ImageIcon vacio;
	private ImageIcon ameba;
	private ImageIcon mariposa;
	private ImageIcon basura;
	private ImageIcon puerta;
	private ImageIcon luciernaga;
	private ImageIcon muroMagico;
	private ImageIcon roca;
	private ImageIcon muroTitanio;
	private ImageIcon diamante;
	private ImageIcon explosion;
	private ImageIcon rockford;
	private ImageIcon rockfordIzquierda;
	private ImageIcon rockfordDerecha;
	private ImageIcon diamanteEstatico;
	private ImageIcon pantallaInicio;
	private ImageIcon juegoTerminado;
	
	private CargarImagenes(){
		cargarNumerosBlancos();
		cargarNumerosAmarillos();
		cargarPersonajes();
	}

	public static CargarImagenes getInstance(){
		if (auxiliar == null)
			auxiliar = new CargarImagenes();
		return auxiliar;
	}
	
	public ImageIcon getNumerosAmarillos(int numero){
		return numerosAmarillos[numero];
	}
	
	public ImageIcon getNumerosBlancos(int numero){
		return numerosBlancos[numero];
	}
	
	public ImageIcon getJuegoTerminado(){
		return juegoTerminado;
	}
	
	public ImageIcon getPantallaInicio() {
		return pantallaInicio;
	}
	
	public ImageIcon getDiamanteEstatico(){
		return diamanteEstatico;
	}

	public ImageIcon getMuro() {
		return muro;
	}
	
	public ImageIcon getVacio() {
		return vacio;
	}

	public ImageIcon getAmeba() {
		return ameba;
	}

	public ImageIcon getMariposa() {
		return mariposa;
	}

	public ImageIcon getBasura() {
		return basura;
	}

	public ImageIcon getPuerta() {
		return puerta;
	}

	public ImageIcon getLuciernaga() {
		return luciernaga;
	}

	public ImageIcon getMuroMagico() {
		return muroMagico;
	}

	public ImageIcon getRoca() {
		return roca;
	}

	public ImageIcon getMuroTitanio() {
		return muroTitanio;
	}

	public ImageIcon getDiamante() {
		return diamante;
	}

	public ImageIcon getExplosion() {
		return explosion;
	}

	public ImageIcon getRockford() {
		return rockford;
	}

	public ImageIcon getRockfordIzquierda() {
		return rockfordIzquierda;
	}

	public ImageIcon getRockfordDerecha() {
		return rockfordDerecha;
	}

	public ImageIcon getMovimientoRockford(int pos) {
		return movimientoRockford[pos];
	}

	private void cargarNumerosBlancos(){
		try{			
			numerosBlancos[0] = cargarImagen("ceroBl.gif");
			numerosBlancos[1] = cargarImagen("unoBl.gif");
			numerosBlancos[2] = cargarImagen("dosBl.gif");
			numerosBlancos[3] = cargarImagen("tresBl.gif");
			numerosBlancos[4] = cargarImagen("cuatroBl.gif");
			numerosBlancos[5] = cargarImagen("cincoBl.gif");
			numerosBlancos[6] = cargarImagen("seisBl.gif");
			numerosBlancos[7] = cargarImagen("sieteBl.gif");
			numerosBlancos[8] = cargarImagen("ochoBl.gif");
			numerosBlancos[9] = cargarImagen("nueveBl.gif");		
		}
		catch(ExcepcionImagenNoEncontrada e){
			e.errorCargarImagen();
		}
	}
	
	
	private void cargarNumerosAmarillos(){
		try{			
			numerosAmarillos[0] = cargarImagen("ceroAm.gif");
			numerosAmarillos[1] = cargarImagen("unoAm.gif");
			numerosAmarillos[2] = cargarImagen("dosAm.gif");
			numerosAmarillos[3] = cargarImagen("tresAm.gif");
			numerosAmarillos[4] = cargarImagen("cuatroAm.gif");
			numerosAmarillos[5] = cargarImagen("cincoAm.gif");
			numerosAmarillos[6] = cargarImagen("seisAm.gif");
			numerosAmarillos[7] = cargarImagen("sieteAm.gif");
			numerosAmarillos[8] = cargarImagen("ochoAm.gif");
			numerosAmarillos[9] = cargarImagen("nueveAm.gif");		
		}
		catch(ExcepcionImagenNoEncontrada e){
			e.errorCargarImagen();
		}
	}
	
	
	private void cargarPersonajes(){					//se cargan las imagenes que contendr� el mapa.
		try{
			ameba = cargarImagen("amoeba.gif");
			mariposa = cargarImagen("butterfly.gif");
			basura = cargarImagen("dirt.gif");
			puerta = cargarImagen("puerta.gif");
			luciernaga = cargarImagen("firefly.gif");
			muroMagico = cargarImagen("magic.gif");
			roca = cargarImagen("rocas.gif");
			muroTitanio = cargarImagen("steel.gif");
			diamante = cargarImagen("diamond.gif");
			vacio = cargarImagen("vacio.gif");
			muro = cargarImagen("muro.gif");
			explosion = cargarImagen("explosion.gif");
			rockford = cargarImagen("rockfordstop.gif");
			rockfordIzquierda = cargarImagen("movIzq.gif");
			rockfordDerecha = cargarImagen("movDer.gif");
			diamanteEstatico = cargarImagen("DiamondStatic.gif");
			movimientoRockford[0] = rockford;
			movimientoRockford[1] = rockfordIzquierda;
			movimientoRockford[2] = rockfordDerecha;
			pantallaInicio = cargarImagen("PantallaInicio.gif");
			juegoTerminado = cargarImagen("finJuego.gif");
		   }
		catch(ExcepcionImagenNoEncontrada e){
			e.errorCargarImagen();
		}
	}
	
			

	private ImageIcon cargarImagen (String imagenUrl) throws ExcepcionImagenNoEncontrada {
		
		URL localizacion = CargarImagenes.class.getResource(imagenUrl);    	
		if (localizacion == null) {
		    throw new ExcepcionImagenNoEncontrada();
		}   
		else {
			return new ImageIcon(localizacion);
		}
	}

}